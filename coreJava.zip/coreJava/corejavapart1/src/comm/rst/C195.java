package comm.rst;
import comm.*;
import comm.lara.*;
public class C195 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A195.test1();
		B195.test2();
		
	}
	public static void test3()
	{
		System.out.println("am from test3()");
	}
}
