package comm;
import comm.lara.*;
import comm.rst.*;
public class A195 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B195.test2();
		C195.test3();
		
	}
	public static void test1()
	{
		System.out.println("am from test1");
	}
}
