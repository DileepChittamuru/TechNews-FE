package comm.lara;
import comm.*;
import comm.rst.*;
public class B195 {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		A195.test1();
		C195.test3();
	}
	public static void test2()
	{
		System.out.println("am from test2()");
	}

}
