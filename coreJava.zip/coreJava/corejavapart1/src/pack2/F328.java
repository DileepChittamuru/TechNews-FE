package pack2;

public class F328 {

	/**
	 * @param args
	 */
	C c1=null;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		F328 f=new F328();
		f.c1=new C();
		System.out.println(f.c1);
		System.out.println(f.c1.i);
		
	}

}
