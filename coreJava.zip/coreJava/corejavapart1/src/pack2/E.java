package pack2;
import pack1.*;
class D
{
	public static int i=30;
}
public class E
{
public static void main(String[] args) {
	System.out.println(D.i);
	System.out.println(pack1.D.i);
}
}
