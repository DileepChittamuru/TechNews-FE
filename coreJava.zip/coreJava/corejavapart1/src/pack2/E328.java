package pack2;

public class E328 {

	/**
	 * @param args
	 */
	C c1=new C();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			E328 e=new E328();
			System.out.println(e.c1.toString());
			System.out.println(e.c1.i);
	}

}
