package pack2;

public class A325 {

	/**
	 * @param args
	 */
	int i;
	static int j;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(j);
		System.out.println(A325.j);
		A325 a=new A325();
		System.out.println(a.i);
		System.out.println(a.j);
	}

}
