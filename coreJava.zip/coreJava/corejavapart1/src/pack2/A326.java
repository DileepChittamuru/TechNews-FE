package pack2;

public class A326 {
	int i;
	void test1()
	{
		System.out.println("test1:"+i);
		i=10;
		test2();
	}
	void test2()
	{
		System.out.println("test2:"+i);
		i=20;
		test3();
	}
	void test3()
	{
		System.out.println("test3:"+i);
		i=30;
		
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A326 a=new A326();
		System.out.println("main1:"+a.i);
		a.test1();
		System.out.println("main2:"+a.i);

	}

}
