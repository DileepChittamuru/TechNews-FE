package pack2;
class C
{
	int i;
}
public  class D328 {

	/**
	 * @param args
	 */
	C c1;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		D328 d=new D328();
		System.out.println(d.c1);
	}

}
