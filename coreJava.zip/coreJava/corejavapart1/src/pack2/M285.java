package pack2;
class Animal
{
	public void move()
	{
		
		 System.out.println("animal");
		 
	}
}
public class M285 extends Animal
{
	public void move()
	{
		System.out.println("move");
	}
	public static void main(String[] args)
	{
		
		Animal  m=new M285();
		m.move();
		
	}
}

