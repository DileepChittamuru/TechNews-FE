package pack2;
class P 
{
	
}
class Q extends P
{
	
}
class R extends Q
{
	
}
class S
{
	Q test()
	{
		return null;
		
	}
	
}
public class A245  extends S
{

	R test()
	{
		return null;
	}
}
