package pack2;

public class A330 {

	/**
	 * @param args
	 */
	void test1()
	{
		System.out.println("test1"+this);
		test2();
	}
	void test2()
	{
		System.out.println("test2:"+this);
		test3();
		
	}
	void test3()
	{
		System.out.println("test3"+this);
	}
	public static void main(String[] args) 
	{
		A330 a=new A330();
		System.out.println("mainbegin:"+a);
		a.test1();
		System.out.println("main:"+a);
	}

}