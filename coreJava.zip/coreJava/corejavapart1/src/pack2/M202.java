package pack2;
import pack1.*;
public class M202 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
L202 obj=new L202();
/*System.out.println(obj.x);*/
	}

}
