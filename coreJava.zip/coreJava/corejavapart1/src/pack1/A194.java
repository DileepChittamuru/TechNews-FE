package pack1;

public class A194 
{
	public static void test1()
	{
		System.out.println("am from A194");
	}
}
