package pack1;

public class Manager194 
{
public static void main(String[] args) {
	System.out.println("main.begin");
	A194.test1();
	System.out.println("main end");
}
}
