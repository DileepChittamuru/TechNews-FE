package pack1;

public class D 
{
	public static int i=20;

}
