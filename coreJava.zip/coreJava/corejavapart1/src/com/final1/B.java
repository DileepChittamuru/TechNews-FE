package com.final1;

public class B {

	final int i;
	/*B()
	{
		i=20;
	}*/
	{
		i=10;
	}
	

	public static void main(String[] args) {
		B b=new B();
		System.out.println(b.i);
		//B b1=new B(100);
		//System.out.println(b1.i);
	}
}
