package com.enums;

public class M10 {

	enum E
	{
		con(10),test(20),set(90);
		  E(int i)
		{
			
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		M10.E m1=E.test;
		System.out.println(m1);
	}

}
