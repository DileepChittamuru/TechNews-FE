package com.enums;

public class M6 {

	enum E
	{
		a,b,c,d;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
                M6.E m1=M6.E.a;
                System.out.println(m1);
                M6.E m2=M6.E.b;
                System.out.println(m2);
                M6.E m3=M6.E.c;
                System.out.println(m3);
                
                System.out.println(m1.ordinal());
                System.out.println(m2.ordinal());
                System.out.println(m3.ordinal());
	}

}
