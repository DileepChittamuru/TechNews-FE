package com.enums;

public class E2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Days d1=Days.MON;
		System.out.println(d1);
		Days d2=Days.TUE;
		System.out.println(d2);
	}

}
