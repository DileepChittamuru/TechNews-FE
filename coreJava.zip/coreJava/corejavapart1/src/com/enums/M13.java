package com.enums;

public class M13 {

	enum A
	{
		con1,con2,
		con3
		{
			void test()
			{
				System.out.println("overide for con3");
			}
		},
		con4,con5;
		void test()
		{
			System.out.println("test method");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		M13.A a=A.con1;
		M13.A a1=A.con2;
		M13.A a2=A.con3;
		M13.A a3=A.con4;
		M13.A a4=A.con5;
		a.test();
		a1.test();
		a2.test();
		a3.test();
		a4.test();
		System.out.println("done");
	}

}
