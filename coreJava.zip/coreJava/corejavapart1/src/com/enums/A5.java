package com.enums;
class A
{
	enum B
	{
		C1,C2,C3;
	}
	 static void test()
	 {
		 B b1=A.B.C1;
		 System.out.println(b1);
		 B b2=A.B.C2;
		 System.out.println(b2);
	 }
}
public class A5
{
		public static void main(String[] args)
	{
		A.B b1=A.B.C1;
		System.out.println(b1);
		A.B b2=A.B.C2;
		System.out.println(b2);
		A.B b3=A.B.C3;
		System.out.println(b3);
		A.test();
		

	}

}
