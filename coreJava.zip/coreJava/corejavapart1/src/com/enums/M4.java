package com.enums;

public class M4 {

	enum A
	{
		CON1,CON2,CON3;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a1=A.CON1;
		System.out.println(a1);
		A a2=A.CON2;
		System.out.println(a2);
	}

}
