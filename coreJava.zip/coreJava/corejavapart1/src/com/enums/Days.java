package com.enums;

 enum Days
{
	MON,TUE,WED,THU,FRI,SAT,SUN;
	
}
