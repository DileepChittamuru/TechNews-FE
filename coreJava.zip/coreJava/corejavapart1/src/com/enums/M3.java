package com.enums;
enum Months
{
	JAN,FEB,MAR,APRL,MAY,JUNE,JULY,AUG,SEPT,OCT,NOV,DEC;
}
public class M3 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Months m1=Months.JAN;
		System.out.println(m1);
	      m1=Months.FEB;
		
	}

}
