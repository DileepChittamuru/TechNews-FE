package com.enums;

public class M11 {

	enum E
	{
		suchi,rishi(10),dile("cdr");
		E()
		{
			System.out.println("cons");
		}
		E(int i)
		{
			System.out.println("rishi");
		}
		E(String s)
		{
			System.out.println("dilee");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		M11.E e=E.rishi;
		System.out.println(e);
		M11.E e1=E.suchi;
		System.out.println(e1);
	}

}
