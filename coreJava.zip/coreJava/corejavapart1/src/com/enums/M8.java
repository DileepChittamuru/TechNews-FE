package com.enums;

public class M8 {

	enum C
	{
		c1,c2,c3;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		M8.C m1=C.valueOf("c1");
		System.out.println(m1);
		M8.C m2=C.valueOf("c2");
		System.out.println(m2);
		M8.C m3=C.valueOf("c3");
		System.out.println(m3);
		M8.C m4=C.valueOf("a");
		System.out.println(m4);
		
	}

}
