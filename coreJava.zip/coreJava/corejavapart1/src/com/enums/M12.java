package com.enums;

public class M12 {

	enum A
	{
		JAN(31),FEB(28),MAR(30);
		int days;
		A(int days)
		{
			this.days=days;
			
		}
		int getDyas()
		{
			return days;
		}
	}
	public static void main(String[] args)
	{
		M12.A a=A.JAN;
		System.out.println(a);
		System.out.println(a.getDyas());
		M12.A a1=A.FEB;
		System.out.println(a1);
		System.out.println(a1.getDyas());
		M12.A a2=A.MAR;
		System.out.println(a2);
		System.out.println(a2.getDyas());
		System.out.println(a2);
		
		

	}

}
