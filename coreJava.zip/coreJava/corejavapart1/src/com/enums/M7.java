package com.enums;

public class M7 {

	enum test
	{
		t1,t2,t3,t4;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	test x[]=test.values();
	for(int i=0;i<x.length;i++)
	{
		System.out.println(x[i]);
	}
	}

}
