package com.staticvarmngmt;

public class B74 {

	/**
	 * @param args
	 */
	static int i;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(i);
		System.out.println(B74.i);
		i=10;
		System.out.println(i);
		System.out.println(B74.i);
		B74.i=20;
		System.out.println(i);
		System.out.println(B74.i);
	}

}
