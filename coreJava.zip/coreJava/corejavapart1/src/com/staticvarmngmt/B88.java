package com.staticvarmngmt;

public class B88 {

	/**
	 * @param args
	 */
	static int x=test();
	static int test()
	{
		System.out.println("A:"+x);
		return 20;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("B:"+x);
	}

}
