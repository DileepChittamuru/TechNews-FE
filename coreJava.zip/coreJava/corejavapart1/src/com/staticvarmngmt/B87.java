package com.staticvarmngmt;

public class B87 {

	/**
	 * @param args
	 */
	static int x=10;
	static int y=test();
	static int test()
	{
		System.out.println("am from test()");
		return 20;
	}
	static int z=test2();
	static int test2()
	{
		System.out.println("am from test2");
		return 40;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);

	}

}
