package com.staticvarmngmt;

public class B67 {

	/**
	 * @param args
	 */
	static int i;
	static void test()
	{
		System.out.println("from test"+i);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("from main:"+i);
	}

}
