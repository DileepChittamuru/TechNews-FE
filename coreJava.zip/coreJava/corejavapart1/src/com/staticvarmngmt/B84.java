package com.staticvarmngmt;

public class B84 {

	
	static void test()
	{
		System.out.println("i am from test");
		i=10;
	}
	static int i;
	public static void main(String[] args) 
	{
		System.out.println("a:"+i);
		test();
		System.out.println("b:"+i);

	}

}
