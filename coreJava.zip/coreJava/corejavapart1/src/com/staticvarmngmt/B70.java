package com.staticvarmngmt;

public class B70 {

	/**
	 * @param args
	 */
	static int i=10,j;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(i);
System.out.println(j);
	}

}
