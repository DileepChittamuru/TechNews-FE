package com.staticvarmngmt;

public class B73 {

	/**
	 * @param args
	 */
	static int i;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(i);
		int i=10;
		System.out.println(i);
		 i=20;
		System.out.println(i);
		 i=30;
		System.out.println(i);
	}

}
