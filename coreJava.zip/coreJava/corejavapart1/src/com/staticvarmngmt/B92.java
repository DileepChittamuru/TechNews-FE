package com.staticvarmngmt;

public class B92 {

	/**
	 * @param args
	 */
	static
	{
		System.out.println("sib");
	 // main(1);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hello  world");

	}

}
