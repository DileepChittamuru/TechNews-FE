package com.staticvarmngmt;

public class B91 {

	static 
	{
		System.out.println("sib");
	}

}
