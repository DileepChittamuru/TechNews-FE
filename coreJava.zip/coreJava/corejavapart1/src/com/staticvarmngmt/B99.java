package com.staticvarmngmt;

public class B99 {

	
	static
	{
		i=10;
	}
	static int i=20;
	public static void main(String[] args) {
		
		System.out.println(i);
	
	}

}
