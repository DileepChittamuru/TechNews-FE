package com.staticvarmngmt;

public class B68 {

	/**
	 * @param args
	 */
	static int i=10;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(i);
	}

}
