package com.staticvarmngmt;

public class B100 {

	/**
	 * @param args
	 */
	static
	{
	x=10;
	}
	static int x=20;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(x);
	}
	

}
