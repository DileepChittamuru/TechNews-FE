package com.staticvarmngmt;
class  A
{
	A()
	{
		System.out.println("a()");
	}
	A(int i)
	{
		System.out.println("a(int)");
	}
	
}
class B extends A
{
	B()
	{
		System.out.println("b()");
	}
	B(int i)
	{
		System.out.println("b(int)");
	}
}
public class B178 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a=new A();
		System.out.println("===========");
		A a1=new A(10);
		System.out.println("==============");
		B b=new B();
		System.out.println("=============");
		B b1=new B(20);
		System.out.println("============");

	}

}
