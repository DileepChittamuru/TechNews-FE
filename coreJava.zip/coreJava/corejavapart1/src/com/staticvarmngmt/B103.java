package com.staticvarmngmt;

public class B103 {

	/**
	 * @param args
	 */
	int id;
	String name;
	static
	{
		B103 b=new B103();
		System.out.println(b.id+":"+b.name);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

/*System.out.println("hello");*/
	}

}
