package com.staticvarmngmt;

public class B76 {

	/**
	 * @param args
	 */
	static int i;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=10;
		System.out.println(i);
		System.out.println(B76.i);
		i=20;
		B76.i=30;
		System.out.println(B76.i);
		System.out.println(i);
	}

}
