package com.staticvarmngmt;

public class B75 {

	/**
	 * @param args
	 */
	static int i;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("a:"+B75.i);
		int i=20;
		System.out.println("b:"+B75.i);
		System.out.println("c:"+i);
		i=30;
		B75.i=40;
		System.out.println("d:"+B75.i);
		System.out.println("e:"+i);
	}

}
