package com.staticvarmngmt;

public class B85 {

	/**
	 * @param args
	 */
	static int i=test();
	static int test()
	{
		return 10;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(i);
	}

}
