package com.staticvarmngmt;

public class B86 {

	/**
	 * @param args
	 */
	static int i=test();
	static int j=10;
	static int test()
	{
		return j;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(i);
		System.out.println(j);
	}

}
