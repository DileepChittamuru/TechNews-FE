package com.staticvarmngmt;

public class B72 {

	/**
	 * @param args
	 */
	static int i,j=10;
	static int k;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(m);
		System.out.println(n);
		System.out.println(p);
	}
	static int m,n=20,p;

}
