package com.staticvarmngmt;

public class A66 {

	/**
	 * @param args
	 */
	static int i;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(i);
	}

}
