package com.staticvarmngmt;

public class B98 {

	
	static int i=10;
	static
	{
		System.out.println(i);
	}
	public static void main(String[] args) {
		
		System.out.println(i);
	}

}
