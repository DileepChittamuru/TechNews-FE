package com.Rough;

public class A {

	
	public static void main(String[] args) {
		
		int j,k,i;
		i=10;
		j=k=20;
		k=50;
		j=30;
		System.out.println(i); // 10
		System.out.println(j); // 30
		System.out.println(k); // 50
	}

}
