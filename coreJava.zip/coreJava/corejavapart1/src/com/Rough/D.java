package com.Rough;

public class D {

	static int i=test();
	static int j=10;
	public static void main(String[] args) 
	{
		System.out.println("2");
		System.out.println(i);
		System.out.println(j);
	}
	static int test()
	{
		System.out.println("1");
		return j;
	}

}
