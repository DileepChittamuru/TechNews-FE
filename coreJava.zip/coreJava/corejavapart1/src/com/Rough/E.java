package com.Rough;

public class E {
	static 
	{
		System.out.println("vvv");
	String all[]=new String[2];
	all[0]="dileep";
	main(all);
	main(all);
	main(null);
	
}
	public static void main(String[] args) {
		System.out.println("hello");
		
	}


}
