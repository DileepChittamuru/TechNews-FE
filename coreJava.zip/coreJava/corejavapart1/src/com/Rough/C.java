package com.Rough;

public class C {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		int i=10,j=20;
		System.out.println(i);
		System.out.println(j);
	}

}
