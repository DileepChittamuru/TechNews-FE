package com.Rough;

public class F {
	
		public static void main(String[] args) {
			double d = 10.0;
			long lon = (int)(short)(byte)(long) d;
			System.out.println(lon);
			
		}

}
