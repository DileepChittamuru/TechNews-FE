package com.Rough;

interface I
{
	 void test2();
	 String s1=null;
			 int j=0;
			 int i=1;
	 
}
public abstract class Exam121 {
	/*final static int  i;
	static
	{
		i=10;
	}*/
 static   void test1()

 {
	 System.out.println("kkhvwldh");
	 
 }
}
