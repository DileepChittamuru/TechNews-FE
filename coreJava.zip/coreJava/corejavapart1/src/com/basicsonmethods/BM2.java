package com.basicsonmethods;

public class BM2 
{
	public static void main(String[] args)
	{
		System.out.println("hello world");//hello world
		test(10); // 
	}
	static void test(int i)
	{
		System.out.println("hello from test");
		System.out.println(i);
	}

}
