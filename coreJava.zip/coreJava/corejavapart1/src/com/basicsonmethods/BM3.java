package com.basicsonmethods;

public class BM3 
{
	public static void main(String[] args)
	{
		System.out.println("HELLO WORLD");
		test(90);
	}
	static void test(int i)
	{
		System.out.println(i);
	}

}
