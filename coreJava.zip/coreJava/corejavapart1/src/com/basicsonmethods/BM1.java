package com.basicsonmethods;

public class BM1
{
		public static void main(String[] args)
	{
		
		System.out.println("hello world");
	}
	static void test()
	{
		/*int i;
		System.out.println(i);*/
		//local variables to be intialized
	}

}
