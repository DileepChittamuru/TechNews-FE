package com.basicsonmethods;

public class BMX {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		System.out.println(i++);
		System.out.println(++i);
		System.out.println(i++ + ++i);
		System.out.println(i++ + --i);
	}

}
