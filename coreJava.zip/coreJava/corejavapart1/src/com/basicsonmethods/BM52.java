package com.basicsonmethods;

public class BM52
{

	
	public static void main(String[] args)
	{
		
		System.out.println("hello world");
		int i=test();
		
		//System.out.println(test1());//we can't print return type test void method body 
		System.out.println(test());
		System.out.println(i);
	}
	static int test()
	{
		System.out.println("test body");
		return 10;
	}
	static void test1()
	{
		System.out.println("test1 body");
	}

}
