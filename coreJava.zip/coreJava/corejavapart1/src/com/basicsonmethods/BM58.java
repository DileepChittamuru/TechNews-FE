package com.basicsonmethods;

public class BM58 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	/*int i;
	test(i);
	System.out.println(i);*///********local var's should be instialized
	}
	static void test(int i)
	{
		i=10;
	}

	}

