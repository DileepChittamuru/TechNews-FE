package com.basicsonmethods;

public class BM55 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println(test());
	}
	static void test()
	{
		System.out.println("test");
	}
}
