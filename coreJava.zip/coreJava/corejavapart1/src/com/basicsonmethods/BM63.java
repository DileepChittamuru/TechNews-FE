package com.basicsonmethods;

public class BM63 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		int j=i++ + test(i)+ i;
		System.out.println(i);
		System.out.println(j);
	}
	static int test(int i)
	{
		System.out.println("test()");
		return i++;
	}

}
