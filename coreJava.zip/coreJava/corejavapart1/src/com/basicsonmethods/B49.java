package com.basicsonmethods;

public class B49 
{
		public static void main(String[] args)
	{
	System.out.println("main");
	test();
	System.out.println("end");
	}
	static void test()
	{
		System.out.println("test");
		return;
		/*System.out.println("end");*/
	}

}
