package com.basicsonmethods;

public class BM53 {

	
	public static void main(String[] args)
	{
		System.out.println("hello main");
		System.out.println(test());
	}
	static int test()
	{
		System.out.println("hello test");
		return 10;
	}

}
