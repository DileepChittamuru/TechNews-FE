package com.basicsonmethods;

public class BM48 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=10;
		System.out.println("a:"+i);
		test(i);
		System.out.println("b:"+i);
	}
	static void test(int i)
	{
		i=20;
		System.out.println("hello");
	}

}
