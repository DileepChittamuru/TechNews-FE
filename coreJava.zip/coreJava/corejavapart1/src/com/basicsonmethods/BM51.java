package com.basicsonmethods;

public class BM51 {

	public static void main(String[] args) 
	{
		
		System.out.println("main1");
		test();
		System.out.println("main2");
	}
	static void test()
	{
		System.out.println("test begin");
		if(true)
		{
			System.out.println("if block");
			return;
		}
		System.out.println("test2 end");
	}

}
