package com.basicsonmethods;

public class BM54 {

	
	public static void main(String[] args) 
	{
		System.out.println("hello world");
		//test();
		int i=10+test();
		System.out.println(i);
		//System.out.println(test());
	}
	static int test()
	{
		System.out.println("from test");
		return 10;
	}

}
