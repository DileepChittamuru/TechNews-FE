package com.casting;

public class A255 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double d=10.9;
		int i=(byte)(short)(float)(long)(double)d;
		System.out.println(i);
		
	}

}
