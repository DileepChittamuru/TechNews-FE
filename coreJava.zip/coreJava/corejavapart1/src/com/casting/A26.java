package com.casting;

public class A26 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			long x=10;
			test((int)x);
			
			}
	public static void test(int i)
	{
		System.out.println(i);
	}

}
