package filehandling3;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
//import java.io.ObjectOutputStream;

public class Man7 {

	/**
	 * @param args
	 */
	public static void main(String[] args)throws IOException ,ClassNotFoundException
	{
		// TODO Auto-generated method stub
		Employee e=new Employee();
		System.out.println(e);
		File f=new File("emp.txt");
		FileInputStream fin=new FileInputStream(f);
		ObjectInputStream in=new ObjectInputStream(fin);
		e.readExternal(in);
		//in.close();
		//fin.close();
		System.out.println(e);
	}

}
