package filehandling3;

import java.io.Serializable;

public class Person implements Serializable
{

	private String name;
	private int age;
	private double weight;
	public Person(String name,int age,double weight)
	{
		this.name=name;
		this.age=age;
		this.weight=weight;
	}
	public String toString()
	{
		return "name :"+name+", age :"+age+"weight :"+weight;
	}

}

