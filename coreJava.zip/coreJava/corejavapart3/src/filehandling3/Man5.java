package filehandling3;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Man5 {

	/**
	 * @param args
	 */
	public static void main(String[] args)throws IOException,ClassNotFoundException
	{
		// TODO Auto-generated method stub
		FileInputStream fin=new FileInputStream("test.ser");
		ObjectInputStream in=new ObjectInputStream(fin);
		C c=(C)in.readObject();
		System.out.println(c);
		System.out.println("done");
	}

}
