package filehandling3;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Man4 {

	
	public static void main(String[] args)throws IOException
	{
	FileOutputStream fout=new FileOutputStream("test.ser");
	ObjectOutputStream out=new ObjectOutputStream(fout);
	C c=new C("don",20,44);
	out.writeObject(c);
	System.out.println(c);
	System.out.println("done");
	}

}
