package filehandling3;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Man2 {

	/**
	 * @param args
	 */
	public static void main(String[] args)throws IOException
	{
		// TODO Auto-generated method stub
		FileOutputStream fout=new FileOutputStream("test.jar");
		ObjectOutputStream out=new ObjectOutputStream(fout);
		Person p=new Person("dilee",20,55);
		out.writeObject(p);
		System.out.println("done");
		
	}

}
