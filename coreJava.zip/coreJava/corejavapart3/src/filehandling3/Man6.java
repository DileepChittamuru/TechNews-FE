package filehandling3;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

public class Man6 {

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args)throws IOException
	{
		
		Employee e= new Employee("dileep",20,43.7);
		FileOutputStream fout=new FileOutputStream("emp.txt");
		ObjectOutputStream out=new ObjectOutputStream(fout);
		
		e.writeExternal(out);
		System.out.println(e);
		System.out.println("done");
		out.flush();
		out.close();
		fout.close();
 
	 }

}
