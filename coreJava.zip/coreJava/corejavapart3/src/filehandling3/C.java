package filehandling3;

import java.io.Serializable;

public class C implements Serializable
{

	private String name;
	private transient int age;
	private int weight;
	public C(String name,int age,int weight)
	{
		this.name=name;
		this.age=age;
		this.weight=weight;
		
	}
	public String toString()
	{
		return "name:"+name+", age:"+age+",weight:"+weight;
		
	}
}
