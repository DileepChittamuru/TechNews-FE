package filehandling3;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class B {

		public static void main(String[] args)throws IOException,ClassNotFoundException
		
		{
		// TODO Auto-generated method stub
			//File f1=new File();
			FileInputStream fin=new FileInputStream("test.ser");
			ObjectInputStream in=new ObjectInputStream(fin);
			A1 a1=(A1)in.readObject();
			System.out.println(a1.i);
			System.out.println(a1.l);
			System.out.println(a1.c);
			System.out.println(a1.d);
			
			
	}

}
