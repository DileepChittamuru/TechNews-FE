package filehandling3;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public class Employee implements Externalizable
{
private String name;
private int age;
private Double weight;
public  Employee()
{
	
}
public Employee(String name,int age,Double weight)
{
	this.name=name;
	this.age=age;
	this.weight=weight;
}
public String toString()
{
	return "name: " +name+ ", age:" +age+ "weight:"+weight;
}
public void writeExternal(ObjectOutput out)throws IOException
{
	out.writeUTF(name);
	out.writeInt(age);
	out.writeDouble(weight);
	
}
public void readExternal(ObjectInput in)throws IOException
{
	name=in.readUTF();
	age=in.readInt();
	weight=in.readDouble();
	
}

	

}
