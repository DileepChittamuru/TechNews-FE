package filehandling3;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
class A1 implements Serializable
{
	int i;
	long l;
	Double d;
	Character c;
	Boolean b;
}
public class A 
{

	public static void main(String[] args) throws IOException
	{
		A1 a1=new A1();
		a1.i=10;
		a1.l=2000000;
		a1.c='a';
		a1.d=123.56;
		
//	File f1=new File("test.ser");
	FileOutputStream fout=new FileOutputStream("test.ser");
	ObjectOutputStream out=new ObjectOutputStream(fout);
	out.writeObject(a1);
	System.out.println("done");
	
	
	}

}
