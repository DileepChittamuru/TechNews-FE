package collectionapi2;

import java.util.HashSet;
class G1
{
	int i,j,k;
	G1(int i,int j,int k)
	{
		this.i=i;
		this.j=j;
		this.k=k;
	}
	public String toString()
	{
		return "("+i+","+j+","+k+")";
		
	}
	
	public int hashCode()
	{
		System.out.println("hashcode");
		String s1=Integer.toString(i);
		String s2=Integer.toString(j);
		String s3=Integer.toString(k);
		int hash=s1.hashCode();
		hash=hash+s2.hashCode();
		hash=hash+s3.hashCode();
		return hash;
	}
	public boolean equals(Object obj)
	{
		System.out.println("equals");
		G1 g1=(G1)obj;
		G1 g2=(G1)obj;
		G1 g3=(G1)obj;
		return (this.i==g1.i)&&(this.j==g1.j)&&(this.k==g1.k);
		
	}
	
	
}
public class Man21 
{

	
	public static void main(String[] args)
	{
		HashSet set=new HashSet();
		set.add(new G1(1,2,3));
																							System.out.println("\n");
		set.add(new G1(2,1,1));
																					System.out.println("\n");
		set.add(new G1(1,2,1));
																							System.out.println("\n");
		set.add(new G1(2,1,3));
																			System.out.println("\n");
		set.add(new G1(3,1,3));
																			System.out.println("\n");																		
		
		set.add(new G1(1,3,3));
		
		//set.add(new G1(3,2,1));

		//set.add(new G1(2,3,4));
		//set.add(new G1(1,2,3));
		System.out.println(set);
		System.out.println(set.size());
		
		
		
		
	}

}
