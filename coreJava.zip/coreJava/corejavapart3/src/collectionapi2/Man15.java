package collectionapi2;

import java.util.HashSet;
import java.util.Iterator;


public class Man15 {
public static void main(String[] args) {
	HashSet set=new HashSet();
	set.add(21);
	set.add(23);
	set.add(44);
	set.add(55);
	set.add(21);
	set.add(44);
	//System.out.println(set);
	Iterator it=set.iterator();
	while(it.hasNext())
	{
		System.out.println(it.next());
	}
	System.out.println(set.size());
}
}
