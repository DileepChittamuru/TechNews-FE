package collectionapi2;

import java.util.Comparator;
import java.util.PriorityQueue;

class A1
{
	int i,j,k;
	A1(int i,int j,int k)
	{
		this.i=i;
		this.j=j;
		this.k=k;
		
	}
	public String toString()
	{
		return "("+i+","+j+","+k+")";
		
	}
}
class B1 implements Comparator
{
	public int compare(Object o1,Object o2)
	{
		A1 a1=(A1)o1;
		A1 a2=(A1)o2;
		return a1.i-a2.i;
	}
}
class C1 implements Comparator
{
	public int compare(Object o1,Object o2)
	{
		A1 a1=(A1)o1;
		A1 a2=(A1)o2;
		return a1.j-a2.j;
	}
}
class D1 implements Comparator
{
	public int compare(Object o1,Object o2)
	{
		A1 a1=(A1)o1;
		A1 a2=(A1)o2;
		return a1.k-a2.k;
	}
}
public class E {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
PriorityQueue pq=new PriorityQueue(20,new C1());
pq.add(new A1(10,20,30));
pq.add(new A1(30,40,50));
pq.add(new A1(23,34,54));
pq.add(new A1(54,43,32));
pq.add(new A1(99,98,87));
System.out.println(pq);
System.out.println(pq.poll());
System.out.println(pq);

	}

}
