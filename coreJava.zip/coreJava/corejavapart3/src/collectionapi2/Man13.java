package collectionapi2;

import java.util.HashSet;

public class Man13 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet set =new HashSet();
		set.add(21);
		set.add(45);
		set.add(56);
		set.add(99);
		set.add(66);
		set.add(33);
		set.add(21);
		set.add(45);
		set.add(56);
		set.add(99);
		System.out.println(set);
		System.out.println(set.size());
		
	}

}
