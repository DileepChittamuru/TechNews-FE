package collectionapi2;

import java.util.HashSet;

public class Man14 {
public static void main(String[] args) {
	HashSet set=new HashSet();
	System.out.println(set.add(23));
	System.out.println(set.add(44));
	System.out.println(set.add(23));
	System.out.println(set.add(44));
	System.out.println(set.size());
	System.out.println(set);
}
}
