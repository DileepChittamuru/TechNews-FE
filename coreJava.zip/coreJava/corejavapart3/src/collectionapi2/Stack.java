package collectionapi2;

import java.util.LinkedList;

class S
{
	private LinkedList list=new LinkedList();
	public void add(Object obj)
	{
		list.add(obj);
		
	}
	public Object processElement()
	{
	return 	list.removeLast();
	}
	public String toString()
	{
		return list.toString();
		
	}
}
public class Stack {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			S s=new S();
			s.add(23);
			s.add(45);
			s.add(56);
			s.add(76);
			s.add(78);
			s.add(96);
			System.out.println(s);
			Object o1=s.processElement();
			System.out.println(o1);
			System.out.println(s);
			
			Object o2=s.processElement();
			System.out.println(o2);
			System.out.println(s);
			
	}

}
