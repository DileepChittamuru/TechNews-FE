package collectionapi2;

import java.util.Comparator;
import java.util.PriorityQueue;

class A
{
	int i,j;
	A(int i,int j)
	{
		this.i=i;
		this.j=j;
		
	}
	public String toString()
	{
		return "("+i+","+j+")";
		
	}
}
class B implements Comparator
{
	public int compare(Object o1,Object o2)
	{
		A a1=(A)o1;
		A a2=(A)o2;
		return a1.i-a2.i;
		
	}
}
class C implements Comparator
{
	public int compare(Object o1,Object o2)
	{
		A a1=(A)o1;
		A a2=(A)o2;
		return a1.j-a2.j;
	}
}
public class PQueue3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue pq=new PriorityQueue(10,new B());
		pq.add(new A(10,30));
		pq.add(new A(20,21));
		pq.add(new A(98,01));
		pq.add(new A(32,20));
		pq.add(new A(21,23));
		System.out.println(pq);
		System.out.println(pq.poll());
		System.out.println(pq);
		System.out.println("=======================");
		System.out.println(pq.poll());
		System.out.println(pq);
		System.out.println(pq.poll());
		System.out.println(pq);
		System.out.println(pq.peek());
		System.out.println(pq);
		System.out.println(pq);
		
	}

}
