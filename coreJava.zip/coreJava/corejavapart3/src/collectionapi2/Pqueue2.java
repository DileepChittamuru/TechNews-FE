package collectionapi2;

import java.util.PriorityQueue;

class PQ implements Comparable
{
	int i;
	PQ(int i)
	{
		this.i=i;
	}
	public String toString()
	{
		return Integer.toString(i);
		
		
	}
	public int compareTo(Object obj)
	{
		PQ  p=(PQ)obj;
		return this.i- p.i;
	}
	
	
}
public class Pqueue2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue pq=new PriorityQueue();
		pq.add(new PQ(21));
		pq.add(new PQ(34));
		pq.add(new PQ(65));
	    System.out.println(pq);
	    System.out.println(pq.poll());
	    System.out.println(pq);
	    
	    System.out.println("==============");
	    System.out.println(pq.poll());
	    System.out.println(pq);
	
		
	}

}
