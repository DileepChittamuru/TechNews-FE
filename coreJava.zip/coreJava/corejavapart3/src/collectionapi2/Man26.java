package collectionapi2;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.TreeSet;

public class Man26 
{
	public static void main(String[] args)
	{
	TreeSet set=new TreeSet(Collections.reverseOrder());
	set.add(21);
	set.add(23);
	set.add(45);
	set.add(33);
	set.add(66);
	set.add(66);
	System.out.println(set);
	System.out.println("hashset");

	HashSet set1=new HashSet();
	set1.add(21);
	set1.add(23);
	set1.add(45);
	set1.add(33);
	set1.add(66);
	set1.add(66);
	TreeSet set2=new TreeSet(set1);
	System.out.println(set2);
	
	
	
	
}
}
