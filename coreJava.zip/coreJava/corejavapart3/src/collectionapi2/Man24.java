package collectionapi2;

import java.util.HashSet;
import java.util.TreeSet;

public class Man24 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet set=new HashSet();
		set.add(90);
		set.add(90);
		set.add(8);
		set.add(88);
		set.add(44);
		set.add(66);
		set.add(44);
		System.out.println(set);
		TreeSet set1=new  TreeSet(set);
		System.out.println(set1);
	}

}
