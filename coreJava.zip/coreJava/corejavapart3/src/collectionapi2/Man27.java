package collectionapi2;

import java.util.TreeSet;

class J1 implements Comparable
{
	int i;
	J1(int i)
	{
		this.i=i;
	}
	public String toString()
	{
		return "i="+i;
	}
	public int compareTo(Object obj)
	{
		J1 j=(J1)obj;
		return this.i-j.i;
	}
}
public class Man27 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet set=new TreeSet();
		set.add(new J1(21));
		set.add(new J1(23));
		set.add(new J1(88));
		set.add(new J1(55));
		set.add(new J1(99));
		set.add(new J1(21));
		set.add(new J1(23));
		System.out.println(set);
	}

}
