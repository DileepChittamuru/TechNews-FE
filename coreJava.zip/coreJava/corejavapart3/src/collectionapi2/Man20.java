package collectionapi2;

import java.util.HashSet;

class F1
{
	int i,j;
	F1(int i,int j)
	{
		this.i=i;
		this.j=j;
		
	}
	public int hashCode()
	{
		System.out.println("hashcode");
		String s1=Integer.toString(i);
		String s2=Integer.toString(j);
		int hash=s1.hashCode();
		hash=hash+s2.hashCode();
		return hash;
		
	}
	public String toString()
	{
		return "("+i+","+j+")";
		
	}
	public boolean equals(Object obj)
	
	{
		System.out.println("equals");
	F1 f1=(F1)obj;
	F1 f2=(F1)obj;
	return (this.i==f1.i) && (this.j==f1.j);
		
	}
	
}
public class Man20 
{
		public static void main(String[] args)
		{
			HashSet set =new HashSet();
			
			
			set.add(new F1(1,2));//hashcode
			System.out.println("\n");
			set.add(new F1(2,1));//hashcode equals
			System.out.println("\n");
			set.add(new F1(1,1));//hashcode
			System.out.println("\n");
			set.add(new F1(1,2));//hashcode  equals equals
			System.out.println("\n");
			set.add(new F1(1,1));//hashcode equals
			System.out.println("\n");
			set.add(new F1(2,2));// hascode
			System.out.println("\n");
			set.add(new F1(3,1));//hashcode equals
			
			System.out.println(set);
			System.out.println(set.size());
			
	
		}
}
