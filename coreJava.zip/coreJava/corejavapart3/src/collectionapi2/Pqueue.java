package collectionapi2;

import java.util.PriorityQueue;

public class Pqueue {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue p1=new PriorityQueue();
		p1.add(21);
		p1.add(32);
		p1.add(45);
		p1.add(67);
		p1.add(88);
		p1.add(36);
		p1.add(55);
		//p1.add(null);
		System.out.println(p1);
		System.out.println(p1.poll());
		System.out.println(p1);
		System.out.println(p1.poll());
		System.out.println(p1);
		System.out.println("*******************************************");
		System.out.println(p1.peek());
		System.out.println(p1);
		System.out.println(p1.peek());
		System.out.println(p1);
	}

}
