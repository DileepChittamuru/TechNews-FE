package collectionapi2;

import java.util.HashSet;

public class Man17 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet set=new HashSet();
		
		
		set.add(21);
		set.add(21);
		System.out.println(set);
		
		
		HashSet  set1=new HashSet();
		set1.add("abc");
		set1.add("abc");
		System.out.println(set1);
		
		HashSet set2=new HashSet();
		set2.add(true);
		set2.add(true);
		System.out.println(set2);
		
		HashSet set3=new HashSet();
		set3.add(new StringBuilder("abc"));
		set3.add(new StringBuilder("abc"));
		System.out.println(set3);
		
		
		
	}

}
