package collectionapi2;

import java.util.Enumeration;
import java.util.ListIterator;
import java.util.Vector;

public class Mvector {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector v1=new Vector();
		v1.add(90);
		v1.add(54);
		v1.add(36);
		v1.add(98);
		v1.add(65);
		System.out.println(v1);
		Enumeration enum1=v1.elements();
		while(enum1.hasMoreElements())
		{
			System.out.print(enum1.nextElement()+",");
		}
		ListIterator lit=v1.listIterator();
		System.out.println("\n");
		while(lit.hasNext())
		{
			System.out.print(lit.next()+",");
		}
	}

}
