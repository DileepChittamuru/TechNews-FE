package collectionapi2;

import java.util.HashSet;

public class Man16 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet set=new HashSet();
		set.add(22);
		set.add("66");
		set.add(55.07);
		set.add(.655);
		set.add(33.99);
		System.out.println(set);
		
		
	}

}
