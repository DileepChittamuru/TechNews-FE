package collectionapi2;

import java.util.LinkedList;

public class Man5 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList list=new LinkedList();
		list.add(21);
		list.add(34);
		list.add(45);
		list.add(39);
		list.add(23);
		list.add(61);
		
		System.out.println(list);
		Object obj=list.removeLast();
		System.out.println(obj);
		System.out.println(list);
		
		
		Object obj1=list.removeFirst();
		System.out.println(obj1);
		System.out.println(list);
		System.out.println("===================");
		System.out.println(list.peek());
	}

}
