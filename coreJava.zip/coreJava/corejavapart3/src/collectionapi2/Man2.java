package collectionapi2;

import java.util.ArrayList;
import java.util.ListIterator;

public class Man2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list=new ArrayList();
		list.add(45);
		list.add(54);
		list.add(76);
		list.add(23);
		System.out.println(list);
		ListIterator lit=list.listIterator();
		while(lit.hasNext())
		{
			Object obj=lit.next();
			if(obj.equals(54))
			{
				lit.set("abc");
			}
			System.out.print(obj+",");
		}
		System.out.println(list);
	}

}
