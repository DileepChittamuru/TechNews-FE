package collectionapi2;

import java.util.HashSet;

class  E1
{
	int i;
	E1(int i)
	{
		this.i=i;
		
	}
	public String toString()
	{
		return "i="+i;
		
	}
	public int hashCode()
	{
		String s1=Integer.toString(i);
		int hash=s1.hashCode();
		return hash;
	}
	public boolean equals(Object obj)
	{
		E1 e1=(E1)obj;
		return this. i== e1.i;
	}
	
	
}
public class Man18 {
public static void main(String[] args) {
	HashSet set=new HashSet();
	set.add(new E1(10));
	set.add(new  E1(20));
	set.add(new E1(30));
	set.add(new E1(33));
	set.add(new E1(5));
	set.add(new E1(5));
	System.out.println(set);
}
}
