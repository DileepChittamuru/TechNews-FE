package collectionapi2;

import java.util.LinkedList;

class Q
{
	private LinkedList list=new LinkedList();
			public void add(Object obj)
			{
				list.add(obj);
				
			}
			public Object processElement()
			{
			return 	list.removeFirst();
			}
			public String toString()
			{
				return list.toString();
				
			}
}
public class Queue1 {

	
	public static void main(String[] args) 
	{
		Q q=new Q();
		q.add(21);
		q.add(31);
		q.add(41);
		q.add(54);
		q.add(45);
		
		q.add(46);
		System.out.println(q);
		
		
		Object o1=q.processElement();
		System.out.println(o1);
		System.out.println(q);
		 

		Object o2=q.processElement();
		System.out.println(o2);
		System.out.println(q);
		
		
	}

}
