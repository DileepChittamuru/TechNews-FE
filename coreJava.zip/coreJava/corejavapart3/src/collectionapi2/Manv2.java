package collectionapi2;

import java.util.LinkedList;

public class Manv2 {
public static void main(String[] args) {
	LinkedList list=new LinkedList();
	list.add(34);
	list.add(25);
	list.add(35);
	list.add(98);
	list.add(38);
	System.out.println(list);
	System.out.println(list.get(0));
	System.out.println(list.get(1));
	System.out.println(list.get(2));
	System.out.println(list.get(3));
	System.out.println(list.get(4));
	list.set(2,"abc ");
	System.out.println(list);
	

}
}
