package collectionapi2;

import java.util.Comparator;
import java.util.TreeSet;

class L1
{
	int i,j;
	L1(int i,int j)
	{
		this.i=i;
		this.j=j;
		
	}
	public String toString()
	{
		return "("+i+","+j+")";
	}
	static class A1 implements Comparator
	{
		public int compare(Object o1,Object o2)
		{
			L1 l1=(L1)o1;
			L1 l2=(L1)o2;
			return l1.i-l2.i;
		}
	}
	static class B1 implements Comparator
	{
		public int compare(Object o1,Object o2)
		{
			L1 l1=(L1)o1;
			L1 l2=(L1)o2;
			return l1.j-l2.j;
		}
	}
}
public class Man29 
{
public static void main(String[] args) 
{
	TreeSet set=new TreeSet(new L1.A1());
	set.add(new L1(1,0));
	set.add(new L1(2,3));
	set.add(new L1(5,2));
	set.add(new L1(1,0));
	set.add(new L1(8,9));
	set.add(new L1(9,9));
	System.out.println(set);
	
	TreeSet set2=new TreeSet(new L1.A1());
	set2.add(new L1(1,0));
	set2.add(new L1(2,3));
	set2.add(new L1(5,2));
	set2.add(new L1(8,9));
	set2.add(new L1(9,9));
	System.out.println(set2);
}

}
