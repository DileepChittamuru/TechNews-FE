package collectionapi2;

import java.util.ArrayList;
import java.util.ListIterator;

public class Man1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list=new ArrayList();
		list.add(20);
		list.add(31);
		list.add(54);
		list.add(98);
		list.add(42);
		System.out.println(list);
		ListIterator lit=list.listIterator();
		lit.add(45);
		while(lit.hasNext())
		{
			System.out.println(lit.next());
		}
		
		lit.add(35);
		System.out.println(list);
		while(lit.hasPrevious())
		{
			System.out.println(lit.previous());
		}
	}

}
