package collectionapi2;

import java.util.LinkedList;

public class Man4 {
public static void main(String[] args) {
	LinkedList list=new LinkedList();
	list.add(21);
	list.add(34);
	list.add(45);
	list.add(39);
	list.add(23);
	list.add(61);
	System.out.println(list);
	Object obj=list.peek();
	System.out.println(obj);
	System.out.println(list);
	Object obj1=list.peek();
	System.out.println(obj1);
	System.out.println(list);
	System.out.println("===================");
	System.out.println(list);
}
}
