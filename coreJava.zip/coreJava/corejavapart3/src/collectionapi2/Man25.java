package collectionapi2;

import java.util.HashSet;
import java.util.TreeSet;

public class Man25 {
public static void main(String[] args) {
	System.out.println("treeset");
	TreeSet set=new TreeSet();
	set.add(21);
	set.add(23);
	set.add(21);
	set.add(34);
	set.add(11);
	set.add(33);
	set.add(88);
	set.add(11);
	System.out.println(set);
	
	System.out.println("hashset");
	HashSet set1=new HashSet();
	set1.add(21);
	set1.add(23);
	set1.add(21);
	set1.add(34);
	set1.add(11);
	set1.add(33);
	set1.add(88);
	set1.add(11);
	System.out.println(set1);
}
}
