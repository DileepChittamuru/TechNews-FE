package strings2;

public class B {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		String s1="cdrinnovation";
		String s2=s1.substring(5,9);
		String s3=s1.substring(5);
		
		
		System.out.println(s3);
		System.out.println(s2);
		System.out.println("=====================");
		String s4=s1.intern();
		System.out.println(s4);
		boolean s6=s1.isEmpty();
		System.out.println(s6);
	}

}
