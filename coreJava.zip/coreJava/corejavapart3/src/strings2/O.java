package strings2;

public class O {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb1=new StringBuffer("ABCDEFGHI");
		System.out.println(sb1);
		sb1.delete(2,5);
		System.out.println(sb1);
		sb1.deleteCharAt(2);
		System.out.println(sb1);
	}

}
