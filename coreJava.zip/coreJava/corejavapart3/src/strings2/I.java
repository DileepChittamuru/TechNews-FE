package strings2;

public class I {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb=new StringBuffer();
		sb.append("***************chittamuru");
		System.out.println(sb);
		sb.append("\n =============================dileep");
		System.out.println(sb);
		sb.append("\n---------------------------------- Reddy");
		System.out.println(sb);
		//sb.append("\n123"); 
		//System.out.println(sb);
	}

}
