package strings2;

public class H {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="abc123";
		//System.out.println(toString(s1.getBytes()))
		
	}

}
