package strings2;

public class F {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="cdr:csr:cgr:cpr:cdR";
		String x[]=s1.split(":");
		for(String s2:x)
		{
			System.out.println(s2);
		}
	}

}
