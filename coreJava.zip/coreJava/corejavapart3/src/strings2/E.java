package strings2;

public class E {

	
	public static void main(String[] args)
	{
		String s1="abc:123:xyz:hello:456";
		String X[]=s1.split(":");
		for(String s:X)
		{
			System.out.println(s);
		}
	}

}
