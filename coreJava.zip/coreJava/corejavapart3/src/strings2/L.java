package strings2;

public class L {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb1=new StringBuffer();
		sb1.append("cdr");
		sb1.append("xyz");
		StringBuffer sb2=new StringBuffer();
		sb2.append("cdr");
		sb2.append("xyz");
		sb2.reverse();
		System.out.println(sb2);
		System.out.println(sb1.equals(sb2));
		System.out.println(sb1.hashCode());
		System.out.println(sb2.hashCode());
		System.out.println("done");
	}

}
