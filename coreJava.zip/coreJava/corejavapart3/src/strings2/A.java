package strings2;

public class A {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		
		// TODO Auto-generated method stub
		String s1="ab1b2c3ab15f";
		System.out.println(s1.length());
		System.out.println(s1.indexOf("ab1"));
		System.out.println(s1.indexOf('4'));//returns index value otherwise negitive value will be returned
		System.out.println(s1.lastIndexOf('b'));
		System.out.println(s1.lastIndexOf('a',2));//up to 2nd value it checks
		System.out.println(s1.lastIndexOf("ab1"));
		
	}

}
