package strings2;

public class J {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="abc";
		StringBuffer sb=new StringBuffer(s1);
		sb.append(  " is don");
		System.out.println(sb);
		sb.append(  "is king");
		System.out.println(sb);
		
	}

}
