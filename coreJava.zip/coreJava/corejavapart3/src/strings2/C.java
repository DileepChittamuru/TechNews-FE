package strings2;

public class C {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		String s1="abc123xyz123xyz";
		System.out.println(s1.codePointAt(2));
		System.out.println(s1.codePointCount(1, 9));
		
		System.out.println(s1.contains("ab"));//returns true or false
		System.out.println(s1.contains("prince"));
		System.out.println(s1.replace('x','h'));
		System.out.println(s1.startsWith("ab"));//returns true or false
		System.out.println(s1.endsWith("yz"));
	}

}
