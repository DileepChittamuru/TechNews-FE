package strings;

public class P {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="abc";
		System.out.println(s1);
		String s2=s1.concat("xyz");
		System.out.println(s2);
	}

}
