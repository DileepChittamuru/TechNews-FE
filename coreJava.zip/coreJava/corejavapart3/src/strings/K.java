package strings;

public class K {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			String s1="hello";
			String s2="HELLO";
	
		System.out.println(s1.equals(s2));
		System.out.println("=============");
		System.out.println(s1.toUpperCase().equals(s2));
		System.out.println("=================");
		System.out.println(s2.toLowerCase().equals(s1));
		System.out.println("=====");
		System.out.println(s1.equalsIgnoreCase(s2));
		System.out.println("=============");
		System.out.println(s2.toLowerCase());
		System.out.println("====");
		System.out.println(s1.toUpperCase());
	}

}
