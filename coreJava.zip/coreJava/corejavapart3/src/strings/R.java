package strings;

public class R {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Hello ,this is a book on java";
		System.out.println(str);
		char arr[]=new char[20];
		str.getChars(0, 20, arr, 0);
		System.out.println(arr);
	}

}
