package strings;

public class G {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="abc";
		String s2="abc";
		String s3=new String("abc");
		String s4=new String("abc");
		System.out.println();
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode()==s3.hashCode());
		System.out.println(s3.hashCode()== s4.hashCode());
		System.out.println(s4.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
	}

}
