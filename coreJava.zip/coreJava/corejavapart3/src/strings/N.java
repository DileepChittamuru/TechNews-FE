package strings;

public class N {

	
	public static void main(String[] args)
	{
		
		String s1="java";
		String s2="ja";
		String s3=s2+"va";
		String s4="ja"+"va";
		String s5=s2.concat("va");
		String s6="va";
		String s7=s2+s6;
		System.out.println(s1==s7);
		System.out.println(s1.equals(s7));
		System.out.println(s7);
		System.out.println(s1==s5);
		System.out.println(s1.equals(s5));
		System.out.println("==========================");
		System.out.println(s3);
		System.out.println(s4);
		System.out.println("===============================");
		System.out.println(s3==s4);
		System.out.println(s1.equals(s4));
		System.out.println("===================================");
		System.out.println(s1==s3);
		System.out.println(s1.equals(s3));
		System.out.println("===========================");
		System.out.println(s1==s4);
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
		
		
		
	}

}
