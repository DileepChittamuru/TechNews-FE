package strings;

public class J {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			String s1="hello";
			String s2="HELLO";
			System.out.println(s1.equals(s2));
			System.out.println("============");
			System.out.println(s1.equalsIgnoreCase(s2));
	}

}
