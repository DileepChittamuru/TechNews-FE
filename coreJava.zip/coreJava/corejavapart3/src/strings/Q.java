package strings;

public class Q {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		String s1="ja";
		String s2="va";
		String s3=s1.concat(s2);
		String s4="                      java                  ";
		String s5=s4.trim();
		System.out.println(s5);
		System.out.println(s5.length());
		System.out.println(s3);
		String s6="abcdefghijkl";
		System.out.println(s6.charAt(2));
		System.out.println(s6.charAt(9));
		System.out.println(s6.charAt(10));
	}

}
