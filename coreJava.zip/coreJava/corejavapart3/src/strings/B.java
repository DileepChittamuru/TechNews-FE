package strings;

public class B {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		
		String s1="abc";
		s1="xyz";
		System.out.println(s1);
		}

}
