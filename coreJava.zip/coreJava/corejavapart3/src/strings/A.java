package strings;

public class A {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="abc";
		System.out.println(s1);
		System.out.println(s1.toString());
		
		String s2="xys";
		System.out.println(s2);
		System.out.println(s2.toString());
		
		
		System.out.println(s2);
	}

}
