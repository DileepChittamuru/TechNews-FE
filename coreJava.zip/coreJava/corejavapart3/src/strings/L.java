package strings;

public class L
{
	public static void main(String[] args)
	{
		String s1="hello";
		System.out.println(s1);
		System.out.println("=============");
		System.out.println("===========");
		String s2=s1.concat("don");
		System.out.println(s2);
		System.out.println("===============");
	}

}
