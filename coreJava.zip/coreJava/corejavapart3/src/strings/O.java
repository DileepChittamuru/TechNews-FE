package strings;

public class O {

	
	public static void main(String[] args) 
	{
		String s1=null;
		System.out.println(s1);
		s1=s1+s1+null;
		System.out.println(s1);
		System.out.println(2+4);
		System.out.println(2+4+"cdr"+3+4+"cdr"+2+8);
		System.out.println("cdr"+2+3);

	}

}
