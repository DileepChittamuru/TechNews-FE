package strings;

public class D {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="lqra";
		String s2=new String("rst");
		System.out.println(s1.toString());
		System.out.println(s2.toString());
		System.out.println(s1);
		System.out.println(s2);
	}

}
