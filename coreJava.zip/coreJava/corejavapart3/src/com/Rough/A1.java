package com.Rough;

public class A1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="java";
		String s2="ja"+"va";
		System.out.println(s1==s2);
		System.out.println(s1.equals(s2));
		System.out.println("================");
		
		String s3="dil";
		String s4="eep";
		String s5="dileep";
		String s6=s3+s4;
		System.out.println(s5==s6);
		System.out.println(s5.equals(s6));
		
	}

}
