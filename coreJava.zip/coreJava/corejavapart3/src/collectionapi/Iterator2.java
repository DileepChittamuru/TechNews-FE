package collectionapi;
import java.lang.*;
import java.util.*;

public class Iterator2 {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		ArrayList list1=new ArrayList();
		list1.add(10);
		list1.add(30);
		list1.add(60);
		list1.add(90);
		list1.add(40);
		System.out.println(list1);
		System.out.println("================");
		Iterator it=list1.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
	}

}
