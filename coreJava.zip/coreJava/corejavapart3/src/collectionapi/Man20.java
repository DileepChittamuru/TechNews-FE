package collectionapi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class I
{
	String name;
	double per;
	int age;
	I(String name,double per,int age)
	{
		this.name =name;
		this.per =per;
		this.age =age;
	}
	public String toString()
	{
		return "("  +name+  ","  +per+  ","  +age+    ")";
	}
	
}
class SortName implements Comparator
{
	public int compare(Object o1,Object o2)
	{
		I i1=(I)o1;
		I i2=(I)o2;
		return i1.name.compareTo(i2.name);
		
	}
}
class  Sortper implements Comparator
{
	public int compare(Object o1,Object o2)
	{
		I i1=(I)o1;
		I i2=(I)o2;
		return (int)(i1.per-i2.per);
	}
}
class Sortage implements Comparator
{
	public int compare(Object o1,Object o2)
	{
		I i1=(I)o1;
		I i2=(I)o2;
		return i1.age-i2.age;
	}
}

public class Man20 {
	public static void main(String[] args) {
		ArrayList  list=new ArrayList();
		list.add(new I("dileep",67.47,23));
		list.add(new I("anusha",62.45,22));
		list.add(new I("seshu",63.32,24));
		list.add(new I("mounica",65.11,26));
		list.add(new I("sunil",71.66,23));
		System.out.println(list);

		Collections.sort(list,new SortName());
		System.out.println("sort by name");
		System.out.println(list);
		Collections.sort(list,new Sortper());
		System.out.println("sort by per");
		System.out.println(list);
		Collections.sort(list,new Sortage());
		System.out.println("sort by age");
		System.out.println(list);
		
		
		
	}

}
