package collectionapi;

import java.util.ArrayList;

public class Man12 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list1=new ArrayList();
		list1.add(20);
		list1.add(21);
		list1.add(32);
		list1.add(2);
		list1.add(25);
		list1.add(56);
		list1.add(64);
		System.out.println(list1);
		ArrayList list2=new ArrayList();
		list2.add(20);
		list2.add(21);
		list2.add(32);
		list2.add(2);
		list1.removeAll(list2);
		System.out.println(list1);
		System.out.println(list2);
	}

}
