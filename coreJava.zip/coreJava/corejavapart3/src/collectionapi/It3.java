package collectionapi;

import java.util.ArrayList;
import java.util.Iterator;

public class It3 {
public static void main(String[] args) {
	ArrayList list=new ArrayList();
	list.add("cdr");
	list.add("csr");
	list.add("cvgr");
	list.add("cpr");
	list.add("cdm");
	System.out.println(list);
	Iterator it=list.iterator();
	while(it.hasNext())
	{
		System.out.println(it.next()+",");
		it.remove();
		
	}
	System.out.println(list);
	System.out.println("==============");
	while(it.hasNext())
	{
		System.out.println(it.next()+",");
	}
}
}
