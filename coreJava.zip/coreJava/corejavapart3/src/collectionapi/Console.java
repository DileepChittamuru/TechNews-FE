package collectionapi;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Console {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter string");
		int i=sc.nextInt();
		
		//StringTokenizer st=new StringTokenizer(,",");
		System.out.println("those tokens are");
		
 	}
}
