package collectionapi;

import java.util.ArrayList;
import java.util.Collections;

class B1 implements Comparable
{
	int i;
	B1(int i)
	{
		this.i=i;
	}
	public String toString()
	{
		return "i="+i;
	}
	public int compareTo(Object obj)
	{
		B1 b=(B1)obj;
		return i-b.i;
	}
	
}
public class Man18 
{

	
	public static void main(String[] args) 
	{
		
		ArrayList list1 =new ArrayList();
		
		list1.add(new B1(10));
	
		System.out.println(list1);
		Collections.sort(list1);
		System.out.println(list1);
	
	
		
	}

}
