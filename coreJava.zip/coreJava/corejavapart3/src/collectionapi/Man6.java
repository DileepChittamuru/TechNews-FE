package collectionapi;

import java.util.ArrayList;

public class Man6 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list1= new ArrayList();
		list1.add(10);
		list1.add(20);
		list1.add(40);
		System.out.println(list1);
		ArrayList list2=new ArrayList();
		list2.add(90);
		list2.add(30);
		list2.add(40);
		
		list2.addAll(1,list1);
		
		
		System.out.println(list2);
		
	}

}
