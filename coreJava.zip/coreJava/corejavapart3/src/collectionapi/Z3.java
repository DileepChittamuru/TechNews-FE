package collectionapi;

import java.util.*;
import java.util.Scanner;

public class Z3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List list=new ArrayList();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter elements");
		list.add(1);
		Object obj= list.add(sc.nextInt());
		if(true)
		{
				
		}
		
		
	}

}
