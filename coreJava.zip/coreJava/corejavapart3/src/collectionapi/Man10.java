package collectionapi;

import java.util.ArrayList;

public class Man10 {
public static void main(String[] args) {
	ArrayList list1=new ArrayList();
	list1.add(20);
	list1.add(21);
	list1.add(32);
	list1.add(2);
	list1.add(25);
	list1.add(56);
	list1.add(64);
	System.out.println(list1);
	list1.clear();
	System.out.println(list1);
}
}
