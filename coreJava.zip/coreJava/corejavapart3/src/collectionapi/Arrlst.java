package collectionapi;

import java.util.ArrayList;

public class Arrlst {
public static void main(String[] args) {
	ArrayList list=new ArrayList();
System.out.println(list.add(90));	
	list.add(1,"abc");
	list.add("cdr");
	list.add("csr");
	list.remove("cdr");
	list.remove(2);
	list.set(1, "don");
	System.out.println(list.lastIndexOf("don"));
	list.add(2);
	
	System.out.println(list.indexOf(2));
	System.out.println(list.get(1));
	System.out.println(list.size());
	System.out.println(list);
	list.clear();
	System.out.println(list);
	}
}
