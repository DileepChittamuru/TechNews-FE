package collectionapi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Binsrch2 {
public static void main(String[] args) {
	ArrayList list=new ArrayList();
	list.add("dileep");
	list.add("seshu");
	list.add("mounica");
	list.add("anusha");
	System.out.println(list);
	System.out.println(Collections.max(list));
	System.out.println(Collections.min(list));
	Comparator ctr=Collections.reverseOrder();
	Collections.sort(list,ctr);
	System.out.println(list);
	int i=Collections.binarySearch(list,"mahesh", ctr);
	System.out.println(i);
}
}
