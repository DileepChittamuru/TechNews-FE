package collectionapi;

import java.util.ArrayList;


public class Man7 {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		ArrayList list1=new ArrayList();
		list1.add(20);
		list1.add(30);
		list1.add(25);
		System.out.println(list1);
		ArrayList list2=new ArrayList(list1);
		list2.add(90);
		System.out.println(list2);
		
	}

}
