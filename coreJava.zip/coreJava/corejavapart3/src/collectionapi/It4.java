package collectionapi;

import java.util.ArrayList;
import java.util.Iterator;

public class It4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list=new ArrayList();
		list.add(10);
		list.add(20);
		list.add(23);
		list.add(32);
		list.add(67);
		//System.out.println(list);
		Iterator it=list.iterator();
		//list.add(60);
		while(it.hasNext())
		{
			Object obj=it.next();
			System.out.println(obj);
			if(obj.equals(23))
			{
				it.remove();
				
			}
		}
		list.add(70);
		System.out.println(list);
	}

}
