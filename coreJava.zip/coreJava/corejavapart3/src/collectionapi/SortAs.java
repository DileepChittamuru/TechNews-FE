package collectionapi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class SortAs {
public static void main(String[] args) {
	ArrayList list =new ArrayList();
	list.add(20);
	list.add(10);
	list.add(30);
	list.add(32);
	list.add(50);
	list.add(30);
	System.out.println(list);
	Collections.sort(list);
	System.out.println(list);
	
	Comparator ctr=Collections.reverseOrder();
	Collections.sort(list,ctr);
	System.out.println(list);
	
}
}
