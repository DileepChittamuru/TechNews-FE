package collectionapi;

import java.util.ArrayList;
import java.util.Collections;

public class Man14 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList list1=new ArrayList();
		list1.add(10);
		list1.add(1);
		list1.add(2);
		list1.add(3);
		list1.add(4);
		list1.add(5);
		list1.add(6);
		list1.add(7);
		System.out.println(list1);
		Collections.sort(list1);
		System.out.println(list1);
	}

}
