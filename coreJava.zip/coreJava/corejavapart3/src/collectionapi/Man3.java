package collectionapi;

import java.util.ArrayList;

public class Man3 {
public static void main(String[] args) {
	
	ArrayList list =new ArrayList();
	list.add(90);
	list.add(true);
	list.add(90.9);
	list.add("abc");
	System.out.println(list);
	System.out.println(list.get(1));
	System.out.println(list.size());
}
}
