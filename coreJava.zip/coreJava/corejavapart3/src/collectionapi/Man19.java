package collectionapi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class F
{
	int i,j;
	F(int i,int j)
	{
		this.i=i;
		this.j=j;
		
	}
	public String toString()
	{
		return "(" + "i="+i+"j="+ j +  ")";
	}
}
class G implements Comparator
{
	public int compare(Object o1,Object o2)
	{
		F f1=(F)o1;
		F f2=(F)o2;
		return f1.i-f2.i;
	}
}
class H implements Comparator
{
	public int compare(Object o1,Object o2)
	{
		F f1=(F)o1;
		F f2=(F)o2;
		return f1.j-f2.j;
	}
}

public class Man19 {

	
	public static void main(String[] args) 
	{
		ArrayList list=new ArrayList();
		list.add(new F(6,3));
		list.add(new F(21,12));
		list.add(new F(8,7));
		list.add(new F(21,56));
		list.add(new F(23,21));
		System.out.println(list);
		Collections.sort(list,new G());
		System.out.println(list);
		Collections.sort(list, new H());
		
	}

}
