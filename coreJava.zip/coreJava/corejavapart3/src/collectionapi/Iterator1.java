package collectionapi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class Iterator1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list=new ArrayList();
		
		list.add(20);
		list.add(10);
		list.add(30);
		list.add(32);
		list.add(50);
		list.add(30);
		
		System.out.println(list);
		System.out.println("===============================");
		Iterator it=list.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next()+",");
		}
		
		System.out.println("==================================");
		
		ListIterator lit=list.listIterator();
		while(lit.hasNext())
		{
			System.out.println(lit.next());
		}
	}

}
