package collectionapi;

import java.util.ArrayList;
import java.util.ListIterator;

public class Itr6 {
public static void main(String[] args) 
{
ArrayList list=new ArrayList();
list.add(10);
list.add(32);
list.add(34);
list.add(98);
list.add(87);
list.add(8);
System.out.println(list);
ListIterator it=list.listIterator();
System.out.println("=============================");
while(it.hasPrevious())
{
	System.out.println(it.previous()+",");
}
System.out.println("=============================");
while(it.hasNext())
{
	System.out.println(it.next()+",");
}
System.out.println("======================");
while(it.hasPrevious())
{
	System.out.println(it.previous()+",");
}
System.out.println("=================");
while(it.hasNext())
{
	System.out.println(it.next()+",");
}

}
}
