package collectionapi;

import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;

public class Z2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList list=new ArrayList();
		
		
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter n value");
		int n=sc.nextInt();
		System.out.println("elements are");
		for(int i=0;i<n;i++)
		{
		Object obj=list.add(sc.nextInt());
		System.out.println(obj);
		}
		System.out.println(list);
	}

}
