package collectionapi;

import java.util.ArrayList;
class A
{
	int i;
	A(int i)
	{
		this.i=i;
	}
	public String toString()
	{
		return "i="+i;
	}
	
}
public class Man17 
{
	public static void main(String[] args)
	{
		
		ArrayList list1=new ArrayList();
		list1.add(1);
		list1.add(2);
		list1.add(3);
		list1.add(4);
		list1.add(5);
		list1.add(6);
		list1.add(7);
		list1.add(new A(10));
		System.out.println(list1);
	}

}
