package collectionapi;

import java.util.ArrayList;




public class B {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		
		ArrayList list=new ArrayList();
		list.add(90);
		list.add(true);
		System.out.println(list.get(0));
		
		
		int i=(Integer)list.get(0);
		
		boolean b=(Boolean)list.get(1);
		System.out.println(i);
		System.out.println(b);
 	}

}
