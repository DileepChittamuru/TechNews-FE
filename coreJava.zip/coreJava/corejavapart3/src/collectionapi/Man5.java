package collectionapi;

import java.util.ArrayList;

public class Man5 {
public static void main(String[] args) {
	ArrayList list=new ArrayList();
	list.add(9);
	list.add(90.9);
	list.add(true);
	System.out.println(list);
	list.add("abc");
	System.out.println(list);
	list.add(2,"dileep");
	System.out.println(list);
	
	
}
}
