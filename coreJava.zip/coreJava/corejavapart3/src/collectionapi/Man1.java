package collectionapi;

import java.util.ArrayList;

public class Man1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list=new ArrayList();
		list.add(100);
		list.add(9.9);
		list.add("abc");
		list.add(true);
		System.out.println(list);
		
	}

}
