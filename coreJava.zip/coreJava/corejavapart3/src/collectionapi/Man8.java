package collectionapi;

import java.util.ArrayList;

public class Man8 {
public static void main(String[] args) {
	ArrayList list1=new ArrayList();
	list1.add(20);
	list1.add(21);
	list1.add(32);
	list1.add(2);
	list1.add(25);
	list1.add(56);
	list1.add(64);
	System.out.println(list1);
	Object obj=list1.remove(3);
	System.out.println(list1);
	System.out.println(obj);
	obj=list1.remove(5);
	System.out.println(obj);
	System.out.println(list1);
	
	
}
}
