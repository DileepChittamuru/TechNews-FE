package collectionapi;

import java.util.ArrayList;
import java.util.ListIterator;

public class Itr5 
{
		public static void main(String[] args)
		{
	ArrayList list=new ArrayList();
	list.add(20);
	list.add(21);
	list.add(54);
	list.add(76);
	list.add(87);
	System.out.println(list);
	
	
	ListIterator it=list.listIterator();
	while(it.hasNext())
	{
		System.out.println(it.next()+",");
	}
	System.out.println("===========================");
	while(it.hasPrevious())
	{
		System.out.println(it.previous()+",");
	}
	
}
}
