package generalprgms;

import java.util.Scanner;

public class Fib
{	
	
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter n value");
		int n=sc.nextInt();
		System.out.println("n value is"+n);
		
		int f1=0;
		int f2=1;
		int f=f1+f2;
		System.out.println(f1);
		System.out.println(f2);
		System.out.println(f);
		
		for(int i=0;i<n;i++)
		{
		f1=f2;
		f2=f;
		f=f1+f2;
		System.out.println(f);
		}
	}
}
