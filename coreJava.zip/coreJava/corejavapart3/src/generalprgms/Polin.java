package generalprgms;

import java.util.Scanner;

public class Polin {

	/*polindrome= reverse of num is to same*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter n value");
		int n=sc.nextInt();
		System.out.println("n value is:"+n);
		
		int m=n;
		int d,s=0;
		while(n!=0)
		{
			d=n%10;
			s=s*10+d;
			n=n/10;
			
		}
		
		if(s==m)
		{
			System.out.println("given num  is polindrome");
		}
		else
		{
			System.out.println("given no.is no polindrome");
		}
		
		
	}

}
