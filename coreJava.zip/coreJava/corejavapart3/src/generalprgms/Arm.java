package generalprgms;

public class Arm {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int d,n=153;
		int s=0;
		int m=n;
		while(n!=0)
		{
			d=n%10;
			s=s+d*d*d;
			n=n/10;
			
			
		}
		if(m==s)
		{
			System.out.println("Armstrong");
		}
		else
		{
			System.out.println("not armstrong");
		}
	}

}
