package generalprgms;

import java.util.Scanner;

public class Pol2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
			Scanner sc=new Scanner(System.in);
			System.out.printf("enter a string :");
			String s=sc.next();
			System.out.println("enter string is :"+s);
		
			StringBuilder sb=new StringBuilder(s);
			sb.reverse();
			System.out.println(sb);
			String str=sb.toString();
			if(str.equalsIgnoreCase(s))
			{
				System.out.println("enter string is polindrome");
			}
			else
			{
				System.out.println("  enter string is not polindrome");
			}
			
	}

}
