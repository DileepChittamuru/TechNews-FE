package arrays2;

import java.util.Arrays;

public class D  implements Comparable

	{
		int i;
		D(int i)
		{
			this.i=i;
			
		}
		public String toString()
		{
			return "i="+i;
			
		}
		public int compareTo(Object obj)
		{
			D d1=(D)obj;
			return d1.i-this.i;
		}
		
		
	public static void main(String[] args) {
		
		
		
		D[] y=new D[]
		            {
				new D(12),
				new D(28),
				new D(23)
				};
		System.out.println(y);
		System.out.println(Arrays.toString(y));
			Arrays.sort(y);
		System.out.println(Arrays.toString(y));
}
}