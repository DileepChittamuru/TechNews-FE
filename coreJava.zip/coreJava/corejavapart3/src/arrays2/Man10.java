package arrays2;

public class Man10 {

	public static void main(String[] args)
	{
		int [][]x=new int[3][];
		int[][] y=new int[2][];
		int z[][]=new int[3][];
		
		x[0]=new int[2];
		x[1]=new int[3];
		x[2]=new int[3];
		x[0][0]=100;
		x[0][1]=25;
		x[1][0]=33;
		x[1][1]=36;
		x[1][2]=44;
		x[2][0]=87;
		
		System.out.println(x[2][2]);
	
		
	}
}
