package arrays2;

import java.util.Arrays;

public class F implements Comparable
{

	int i,j;
	F(int i,int j)
	{
		this.i=i;
		this.j=j;
	}
	public String toString()
	{
		return "("+i+","+j+ ")";
	}
	public int compareTo(Object obj)
	{
		F f=(F)obj;
		return this.i-f.i;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		F f[]={
				new F(10,7),
				new F(8,0),
				new F(9,12),
				new F(32,16),
				new F(8,19)
				};
		System.out.println(Arrays.toString(f));
		Arrays.sort(f);
	    System.out.println(Arrays.toString(f));
		
	}

}
