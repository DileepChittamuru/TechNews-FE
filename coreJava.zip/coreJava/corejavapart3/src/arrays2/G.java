package arrays2;

import java.util.Arrays;
import java.util.Comparator;
class H
{
	int i,j;
	H(int i,int j)
	{
		this.i=i;
		this.j=j;
	}
	public String toString()
	{
		return "("+i+":"+j+")";
	}

}
class I implements Comparator

{
	public int compare(Object o1,Object o2)
	{
		H h1=(H)o1;
		H h2=(H)o2;
		return h1.i-h2.i;
	}
}
class J implements Comparator
{
	public int compare(Object o1,Object o2)
	{
		H  h1=(H)o1;
		H h2=(H)o2;
		return h1.j-h2.j;
	}
}
public class G {
	
		
	
	
	
	public static void main(String[] args)
	{
		H g[]={
				new H(12,34),
				new H(8,23),
				new H(6,43),
				new H(54,45)
		};
		System.out.println(Arrays.toString(g));
		Arrays.sort(g,new I());
		System.out.println(Arrays.toString(g));
	//	System.out.println(g);
		Arrays.sort(g,new J());
		System.out.println(Arrays.toString(g));
	}

}
