package arrays2;

public class Man9 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x[][]=new int[3][2];
		x[0][0]=10;
		x[0][1]=20;
		x[1][0]=30;
		x[1][1]=40;
		x[2][1]=50;
		x[2][0]=60;
		for(int i=0;i<x.length;i++)
		{
			for(int j=0;j<x[i].length;j++)
			{
				System.out.println(x[i][j]);
			}
		}
	}

}
