package arrays2;
import java.util.*;
public class E implements Comparable
{
	int i;
	E(int i)
	{
		this.i=i;
	}
	public String toString()
	{
		return "i="+i;
	}

	public int compareTo(Object obj)
	{
		E e1=(E)obj;
		
	return	i-e1.i;
	}
	public static void main(String[] args) {
		int[] x={10,30,40,50};
		Integer y[]={new Integer(9),19,23,new Integer(78)};
		String z[]={"abc","xyz",new String("cdr"),"90"};
		D[] p={
				new D(30),
				new D(20),
				new D(60)
			};
		E[] e={ new E(60),new E(34)};
		System.out.println(Arrays.toString(x));
		Arrays.sort(x);
		System.out.println(Arrays.toString(x));
		System.out.println("=====================================");
		System.out.println(Arrays.toString(y));
		Arrays.sort(y);
		System.out.println(Arrays.toString(y));
		System.out.println("=======================================");
		
		System.out.println(Arrays.toString(z));
		Arrays.sort(z);
		System.out.println(Arrays.toString(z));
		System.out.println("============================================");
		System.out.println(Arrays.toString(p));
		Arrays.sort(p);
		System.out.println(Arrays.toString(p));
		System.out.println("===========================================");
		System.out.println(Arrays.toString(e));
		Arrays.sort(e);
		System.out.println(Arrays.toString(e));
				
				
	}

}
