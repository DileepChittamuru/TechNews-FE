package arrays2;
import java.util.*;
public class A 
{

	int i;
	A(int i)
	{
		this.i=i;
		
	}
	public String toString()
	{
		return "i="+i;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A[] x=new A[2];
		x[0]=new A(90);
		x[1]=new A(90);
		A[] y={
				new A(9),
				new A(10)
				
				};
		
		System.out.println(x);
		System.out.println(Arrays.toString(x));
		System.out.println(Arrays.toString(y));
		
	}

}
