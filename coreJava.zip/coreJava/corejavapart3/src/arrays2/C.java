package arrays2;

import java.util.Arrays;

public class C {
		int i;
		C(int i)
		{
			this.i=i;
			
		}
		public String toString()
		{
			return "i="+i;
			
		}
		
	public static void main(String[] args) {
		
		C[] x=new C[3];
		x[0]=new C(23);
		x[1]=new C(33);
		x[2]=new C(21);
		System.out.println(x);
		System.out.println(Arrays.toString(x));
		//Arrays.sort(x);
		System.out.println(Arrays.toString(x));
		
		C[] y=new C[]{new C(12),new C(27),new C(23)};
		System.out.println(y);
		System.out.println(Arrays.toString(y));
		//Arrays.sort(y);
		System.out.println(Arrays.toString(y));
	}

}
