package arrays2;

import java.util.Arrays;
import java.util.Comparator;

class Person
{
	String name;
	int age;
	double weight;
	Person(String name,int age,double weight)
	{
		this.name=name;
		this.age=age;
		this.weight=weight;
		
	}
	public String toString()
	{
		return "("+name+","+age+","+weight+")";
	}
	static class SortBasedonName implements Comparator
	{
		public int compare(Object o1,Object o2)
		{
			Person p1=(Person)o1;
			Person p2=(Person)o2;
			return p1.name.compareTo(p2.name);
			
		}
	}
	static class SortBasedonAge implements Comparator
	{
		public int compare(Object o1,Object o2)
		{
			Person p1=(Person)o1;
			Person p2=(Person)o2;
			return p1.age-p2.age;
			
		}
	}
	static class SortBasedonWeight implements Comparator
	{
		public int compare(Object o1,Object o2)
		{
			Person p1=(Person)o1;
			Person p2=(Person)o2;
			return (int)(p1.weight-p2.weight);
			
		}
	}
	
}

public class Man8 {
	public static void main(String[] args)
	{
		Person x[]={new Person("cdr",23,55),
					new Person("csr",28,75),
					new Person("cvgr",54,85),
					new Person("cdm",24,70),
					new Person("cpm",50,68)
					
		
		};
		System.out.println(Arrays.toString(x));
		System.out.println("sort based on Nmae");
		Arrays.sort(x,new Person.SortBasedonName());
		System.out.println(Arrays.toString(x));
		System.out.println("sort based on Age");
		Arrays.sort(x,new Person.SortBasedonAge());
		System.out.println(Arrays.toString(x));
		System.out.println("sort based on weight");
		Arrays.sort(x,new Person.SortBasedonWeight());
		System.out.println(Arrays.toString(x));
		
	}
}
