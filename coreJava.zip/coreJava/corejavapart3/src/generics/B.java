package generics;
class Z1
{
	String s1;
	Integer i;
}
public class B {

	
	public static void main(String[] args) {
		Z1 z=new Z1();
		z.s1="abc";
		z.i=10;
		
		System.out.println(z.s1);
		System.out.println(z.i);

	}

}
