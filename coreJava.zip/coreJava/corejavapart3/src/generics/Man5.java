package generics;
class J<Z>
{
	Z i;
	J()
	{
		
	}
	J(Z i)
	{
		System.out.println("cons");
	}
	  void set(Z i)
	{
		System.out.println("arg type generic");
	}
	Z get()
	{
		System.out.println("return type generic");
		return i;
	}
}
public class Man5 {

	public static void main(String[] args)
	{
		
		J<String> j=new J<String>("abc");
		j.set("cdr");
		J<Integer> j1=new J<Integer>(90);
		String s1=j.get();
		Integer i=j1.get();
		
		System.out.println(s1);
		System.out.println(i);
		System.out.println("done");
		
	}

}
