package generics;
class Z
{
	int i;
}
public class A 
{
	public static void main(String[] args)
	{
		Z z=new Z();
		Z z1=new Z();
		Z z2=new Z();
		System.out.println(z.i);
		System.out.println(z1.i);
		System.out.println(z2.i);
	}

}
