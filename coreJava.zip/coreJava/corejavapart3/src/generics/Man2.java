package generics;
class G<A,B,C>
{
	A i,j;
	B p,q;
	C m,n;
}
public class Man2 
{
	public static void main(String[] args)
	{
		G<Integer,String,Character> g1=new G<Integer,String,Character>();
		g1.i=10;
		g1.j=20;
		g1.p="cdr";
		g1.q="cdm";
		g1.m='a';
		g1.n='d';
		System.out.println(g1.i);
		System.out.println(g1.j);
		System.out.println(g1.p);
		System.out.println(g1.q);
		System.out.println(g1.m);
		System.out.println(g1.n);

	}

}
