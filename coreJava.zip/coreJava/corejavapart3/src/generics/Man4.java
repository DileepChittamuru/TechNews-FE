package generics;
class I<E>
{
	E attri;
	I(E attri,int i)
	{
		this.attri=attri;
	}
}
public class Man4
{

	
	public static void main(String[] args) 
	{
		
		I<String> i=new I<String>("cdr",20);
		System.out.println(i.attri);
		I<Integer> i1=new I<Integer>(20,20);
		System.out.println(i1.attri);
		I<Double> i2=new I<Double>(4.90,30);
		System.out.println(i2.attri);
		
	}

}
