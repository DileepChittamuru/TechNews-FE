package generics;
class H<Test>
{
	void method(Test i)
	{
		System.out.println("method1");
	}
}
public class Man3 
{
	public static void main(String[] args) 
	{
		H<Integer> h=new H<Integer>();
		h.method(10);
		H<String> h1=new H<String>();
		h1.method("cdr");
	
	}

}
