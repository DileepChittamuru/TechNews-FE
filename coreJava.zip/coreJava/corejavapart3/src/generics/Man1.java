package generics;
class E<A,B>
{
	A i,j;
	B m,n;
	String p,q;
	int r,s;
}
public class Man1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		E<String,String> e1=new E<String,String>();
		e1.m="abc";
		e1.n="cdr";
		e1.i="dfr";
		e1.j="gg";
		E<Integer,String> e2=new E<Integer,String>();
		e2.i=10;
		e2.j=10;
		e2.m="cdr";
		e2.n="ddd";
		E<String,Character> e3=new E<String,Character>();
		e3.i="dileep";
		e3.j="divya";
		e3.m='q';
		e3.n='p';
		
		
		
	}

}
