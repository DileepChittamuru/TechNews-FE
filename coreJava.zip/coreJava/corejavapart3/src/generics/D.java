package generics;
class Man<X>
{
	String s1;
	X s2;
	
}
public class D {

	
	public static void main(String[] args)
	{
		
		Man<String> m=new Man<String>();
		m.s1="abc";
		m.s2="cdr";
		Man<Integer> m1=new Man<Integer>();
		m1.s1="cdr1";
		m1.s2=9;
		System.out.println(m1.s1);
		System.out.println(m1.s2);
		
		
	}

}
