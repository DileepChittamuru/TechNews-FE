package generics;
class Z2<X>
{
	X i;
}
public class C 
{

	
	public static void main(String[] args) {
		Z2<Integer> z=new Z2<Integer>();
		Z2<String> z1=new Z2<String>();
		Z2<Double> z2=new Z2<Double>();
		Z2<Float> z3=new Z2<Float>();
		Z2<Character> z4=new Z2<Character>();
		
		z.i=10;
		z1.i="abc";
		z2.i=90.9;
		z4.i='d';
		System.out.println(z.i);
		System.out.println(z1.i);
		System.out.println(z2.i);
		System.out.println(z4.i);
		
	}

}
