package filehandling;

import java.io.File;

public class P {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f=new File("I:/sss/cdr/cdr/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/");
		System.out.println(f.mkdirs());
	}

}
