package filehandling;

import java.io.File;
import java.io.IOException;

public class K 
{
	public static void main(String[] args) 
	{
	File f=new File("I:/lab");
	System.out.println(f.mkdir());
	File f1=new File(f,"hello.txt");
	try
	{
		System.out.println(f1.createNewFile());
	}
	catch(IOException e)
	{
		System.out.println(e);
	}
	System.out.println("done");

	}

}
