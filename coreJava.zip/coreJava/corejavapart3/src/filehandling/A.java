package filehandling;
import java.io.File;
import java.io.IOException;
public class A
{
	public static void main(String[] args) throws IOException
	{
		File f1=new File("abc1.txt");
		boolean b=f1.createNewFile();
		System.out.println(b);
		System.out.println("done");

	}

}
