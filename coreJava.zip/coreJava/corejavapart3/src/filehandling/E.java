package filehandling;

import java.io.File;
import java.io.IOException;

public class E {

	//here creating hello file in lab folder
	public static void main(String[] args) 
	{
	File f1=new File("I:\\lab\\hello.txt");	
		try
		{
			System.out.println(1);
			System.out.println(f1.createNewFile());
			System.out.println(2);
		}
		catch(IOException e)
		{
			e.printStackTrace();
			
		}
		System.out.println("done");
	}

}
