package filehandling;

import java.io.File;
import java.io.IOException;

public class D {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f1=new File("sql.properties");
		try
		{
			System.out.println(f1.createNewFile());
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		System.out.println("done");
	}

}
