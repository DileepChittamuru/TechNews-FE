package filehandling;

import java.io.File;
import java.io.IOException;

public class B {

	/**
	 * @param args
	 */
	public static void main(String[] args)throws IOException
	{
		// TODO Auto-generated method stub
		File f1=new File("ddr.txt");
		System.out.println(f1.exists());
		System.out.println(f1.createNewFile());
		System.out.println(f1.exists());
		
	}

}
