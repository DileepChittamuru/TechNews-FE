package filehandling;

import java.io.File;

public class H {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f=new File("I:/abc/hello/test");
		System.out.println(f.mkdir());
		System.out.println("done");
	}

}
