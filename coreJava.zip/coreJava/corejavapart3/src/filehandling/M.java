package filehandling;

import java.io.File;
import java.io.IOException;

public class M {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		//System.out.println(1);
		File f=new File("I:/abc","abc.txt");
		try
		{
			System.out.println(f.createNewFile());
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
		System.out.println("done");

	}

}
