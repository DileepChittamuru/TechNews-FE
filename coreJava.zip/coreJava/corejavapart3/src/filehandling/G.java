package filehandling;

import java.io.File;

public class G
{

	
	public static void main(String[] args) 
	{
		File f1=new File("I:\\hello");
		
			System.out.println(f1.exists());
			System.out.println(f1.mkdir());
			System.out.println(f1.exists());
		

	}

}
