package filehandling;

import java.io.File;

public class J {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		File f=new File("I:/abc/hello/test");
		System.out.println(f.mkdirs());
		System.out.println("done");
		

	}

}
