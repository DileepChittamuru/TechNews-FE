package filehandling;

import java.io.File;
import java.io.IOException;

public class O {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f=new File("csr");
		System.out.println(f.mkdir());
		File F1=new File(f,"csr.txt");
		try
		{
			System.out.println(F1.createNewFile());
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
		System.out.println("done");
		System.out.println(f.isFile());
		System.out.println(f.isDirectory());
		System.out.println("*******************8");
		System.out.println(F1.isFile());
		System.out.println(F1.isDirectory());
		
		
	}

}
