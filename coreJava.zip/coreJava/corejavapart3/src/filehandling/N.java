package filehandling;

import java.io.File;

public class N {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		File f=new File("abc");
		File f1=new File("abc/hello.txt");
		
		System.out.println(f.isFile());
		System.out.println(f.isDirectory());
		
		System.out.println(f1.isFile());
		System.out.println(f1.isDirectory());
	}

}
