package filehandling;

import java.io.File;

public class L 
{

	public static void main(String[] args) 
	{
		File f=new File("abc");
		File f1=new File(f,"abc");
		System.out.println(f1.mkdir());
	}

}
