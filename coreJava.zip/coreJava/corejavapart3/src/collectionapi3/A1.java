package collectionapi3;

public class A1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList1 list=new ArrayList1();
		list.add(21);
		list.add(33);
		System.out.println(list);
	}

}
