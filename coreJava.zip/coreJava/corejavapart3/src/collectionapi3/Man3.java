package collectionapi3;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class Man3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap map=new HashMap();
		map.put("abc"," v1");
		map.put("key", "v2");
		map.put("key1", "v21");
		map.put("key2", "v22");
		map.put("key3", "v23");
		map.put("key4", "v24");
		map.put("key5", "v25");
		System.out.println(map);
		
		Set set=map.keySet();
		Iterator it=set.iterator();
		while(it.hasNext())
		{
			Object key=it.next();
			Object value=map.get(key);
			System.out.println(key+":"+value);
		}
		
		
	}
}


