package collectionapi3;
public class Arraylist
{
private Object elements[];
private int capacity;
private int size;

	public Arraylist() 
	{
		 capacity=10;
		 elements=new Object[capacity];
		
		
	}
	public void add(Object obj)
	{
		if(size == capacity)
		{
			altercapacity();
		}
		elements[size++] = obj;
	}
	private void altercapacity()
	{
		
		Object[] temp=elements;
		capacity =capacity*2;
		elements=new Object[capacity];
		for(int j=0;j<temp.length;j++)
		{
			elements[j]=temp[j];
		}
		 
	}
	public Object get(int index)
	{
		if(index < 0 ||index >=size)
		{
			throw new  IndexOutOfBoundsException("index should be between 0 to"+(size-1));
		}
		return elements[index];
	}
	public int size()
	{
		return size;
	}
	public String toString()
	{
		StringBuffer sb=new StringBuffer("[");
		for(int j=0;j<size;j++)
		{
			sb.append(elements[j]+",");
			
		}
		return sb.substring(0,sb.length()-1)+"]";
		}
	
	}

