package collectionapi3;

import java.util.Hashtable;

public class Man4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hashtable tab=new Hashtable();
		tab.put(21,"dileep");
		tab.put(23, "dt");
		tab.put(3, "seshu");
		tab.put(53, "mouni");
		System.out.println(tab);
		System.out.println(tab.get(21));
		System.out.println(tab.get(23));
		System.out.println(tab.get(3));
		System.out.println(tab.get(53));
		System.out.println(tab);
	}

}
