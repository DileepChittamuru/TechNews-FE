package collectionapi3;

import java.util.HashMap;

public class Man2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap map=new HashMap();
		map.put("abc", 10000);
		System.out.println(1+":"+map);
		map.put("abc", 2000);
		System.out.println(2+":"+map);
		map.put("abc",3000);
		System.out.println(3+":"+map);
	}

}
