package collectionapi3;

import java.util.Hashtable;

public class Man5 {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Hashtable tab=new Hashtable();
		tab.put(null, "abc");
		tab.put("test", null);
		System.out.println(tab);
	}

}
