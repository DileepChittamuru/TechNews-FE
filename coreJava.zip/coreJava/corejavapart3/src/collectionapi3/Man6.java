package collectionapi3;

import java.util.Hashtable;
class D
{
	int i;
	D(int i)
	{
		this.i=i;
	}
	public String toString()
	{
		return "( i="+i+")";
	}
}

public class Man6 
{
public static void main(String[] args)
{
	Hashtable tab=new Hashtable();
	tab.put("abc", 100);
	tab.put("abc", 2000);
	
	tab.put(10, 20);
	tab.put(10, 30);
	
	tab.put('a',2500);
	tab.put('a', 4000);
	
	tab.put(90.0,'a');
	tab.put(90.0,'d');
	
	tab.put(new D(10), 100);
	tab.put(new D(10), 3000);
	System.out.println(tab);
	
}
}
