package collectionapi3;

import java.util.Collections;
import java.util.TreeMap;

public class Man9 {
public static void main(String[] args) {
	try
	{
	TreeMap map=new TreeMap();
	map.put("key1","dileep");
	map.put("key2","akka");
	map.put("key3"," anna");
	System.out.println(map);
	map.put(20,"suri");
	
	System.out.println(map);
	TreeMap map1=new TreeMap();
	System.out.println(map1);
	}
	catch(Exception e)
	{
	//e.printStackTrace();
	}
}
}
