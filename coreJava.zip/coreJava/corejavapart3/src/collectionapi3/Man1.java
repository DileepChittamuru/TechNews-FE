package collectionapi3;

import java.util.HashMap;

public class Man1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap map=new HashMap();
		map.put(1, "abc");
		map.put(2, "cdr");
		map.put(3, "dileep");
		map.put(5, "don");
		map.put(null, "arg");
		map.put(7, null);
		map.put(null, null);
		map.put('a',30);
		map.put("abc", 89);
		map.put(true, 90);
		map.put(false, "doni");
		System.out.println(map.get(true));
		map.put(90,90);
		map.put('a',true);
		map.put('c', false);
		map.put("key1"," gopal");
		map.put("key2", 300000);
		System.out.println(map);
	}

}
