package collectionapi3;

public class Vector 
{
private int capacity,size;
private Object elements[];
public Vector()
{
	capacity=10;
	elements=new Object[capacity];
	
}
public void add(Object obj)
{
	
	if(size==capacity)
	{
		alterCapicity();
	}
	elements[size++]=obj;
}
private void alterCapicity()
{
	Object temp[]=elements;
	capacity=capacity*2;
	elements=new Object[capacity];
	for(int i=0;i<temp.length;i++)
	{
		elements[i]=temp[i];
	}
}
public int size()
{
	return size;
}
public Object get(int index)
{
	if(index<0||index>size)
	{
		throw new IndexOutOfBoundsException("index should be 0 to"+(size-1));
	}
	return elements[index];
}
public String toString()
{
	StringBuffer sb=new StringBuffer("[");
	for(int i=0;i<size;i++)
	{
		sb.append(elements[i]+",");
	}
	return sb.substring(0,sb.length()-1)+"]";
}
}
