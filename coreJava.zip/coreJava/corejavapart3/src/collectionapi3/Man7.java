package collectionapi3;

import java.util.HashMap;
class E
{
	int i;
	E(int i)
	{
		this.i=i;
	}
	public String toString()
	{
		return "i="+i;
	}
	public int hashCode()
	{
		String s1=Integer.toString(i);
		int hash=s1.hashCode();
		return hash;
	}
	public boolean equals(Object obj)
	{
		E e=(E)obj;
		return this.i==e.i;
		
	}
}
class F
{
	int i;
	F(int i)
	{
		this.i=i;
	}
	public String toString()
	{
		return "i="+i;
	}
	
	public int hashCode()
	{
		String s1=Integer.toString(i);
		int hash=s1.hashCode();
		return hash;
	}
	public boolean equals(Object obj)
	{
		F f=(F)obj;
		return this.i==f.i;
	}
	
}
public class Man7 
{
	public static void main(String[] args) 
	{
		
		HashMap map=new HashMap();
		map.put(90,"e1");
		map.put(90,"e2");
		
		map.put("abc","v1");
		map.put("abc","v2");
		
		map.put(new E(10),"dileep");
		map.put(new E(10),"chiru");
		
		map.put(new F(20),"megastar");
		map.put(new F(20),"suprem hero");
		
		map.put(new StringBuffer(10),"dileep reddy");
		map.put(new StringBuffer(10), "subba reddy");
		
		
		
		System.out.println(map);
		
		
	
		
	}
}
