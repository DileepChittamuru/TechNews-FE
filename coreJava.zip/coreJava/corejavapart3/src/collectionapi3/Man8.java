package collectionapi3;

import java.util.HashMap;
import java.util.TreeMap;

public class Man8 
{

	
	public static void main(String[] args)
	{
		HashMap map=new HashMap();
		map.put("key", 2000);
		map.put("abc", 2900);
		map.put("key3",8000);
		map.put("key5", 3000);
		System.out.println(map);
		
		TreeMap map1=new TreeMap(map);
		
		System.out.println(map1);
		
		
	}

}
