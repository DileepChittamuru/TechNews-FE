package collectionapi3;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.TreeMap;
class G implements Comparable
{
	int i;
	G(int i)
	{
		this.i=i;
	}
	public String toString()
	{
		return "i="+i;
	}
	public int compareTo(Object obj)
	{
		G g=(G)obj;
		return this.i-g.i;
	}
	/*public int hashCode()
	{
		String s1=Integer.toString(i);
		int hash=s1.hashCode();
		return hash;
	}
	public boolean equals(Object obj)
	{
		G g=(G)obj;
		return this.i==g.i;
	}*/
	
}
public class Man10 
{
public static void main(String[] args) 
{
	Hashtable map=new Hashtable();
	map.put(new G(10),"abc");
	map.put(new G(20), "daya");
	map.put(new G(20),"cdr");
	map.put(new G(30), "csr");
	map.put(new G(40), "cdm");
	map.put(new G(30), "athamma");
	System.out.println(map);
}
}
