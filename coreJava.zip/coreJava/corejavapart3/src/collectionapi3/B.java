package collectionapi3;

import java.util.LinkedList;
import java.util.Scanner;

public class B {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList list=new LinkedList();
		Arraylist list1=new Arraylist();
		Scanner sc=new Scanner(System.in);
		String s;
		
		System.out.println("enter a words");
	do
		{
		
		
		 s=sc.next();
		list.add(s);
		
		}
	while(!(s.equals("exit")));
	    list.remove("exit");
		System.out.println("words are:"+list);
		System.out.println("no of words are:"+list.size());
	for(int i=0;i< list.size();i++)
		{
			
		System.out.println(list.get(i));
		     
		       if(  (list.get(i)).equals (list.get(i++) ))
				{
		    	   System.out.println(list);
		    	  
			
				}
		
		       
		        }
		
	}

}
