package collectionapi3;

public class Vector1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector list=new Vector();
		list.add(21);
		list.add(44);
		System.out.println(list);
	}

}
