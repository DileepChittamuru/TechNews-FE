package collectionapi3;

import java.util.Collection;
import java.util.Collections;

public class LinkedList1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
LinkedList list=new LinkedList();
list.add(21);
list.add(22);
list.add(88);
list.iterate();
LinkedList list1=new LinkedList();
list1.add(21);
list1.add(23);
list1.add(19);

	}

}
