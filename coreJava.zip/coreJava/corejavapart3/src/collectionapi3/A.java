package collectionapi3;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class A {

	
	public static void main(String[] args)
	{
		LinkedList  list=new LinkedList();
		
		//System.out.println(list);
		Scanner sc=new Scanner(System.in);
		int choice=0;
		int ele;
		while(choice<4)
		{
			

			System.out.println("enter your choice");
			
			choice =sc.nextInt();
			
									switch(choice)
									{
									case 1:System.out.println("enter element\t");
											  ele = sc.nextInt();
											list.add(ele+1);
											break;
								
									default:	
										System.out.println("out of choice");
									}
									
									
			System.out.println("list contains are:");
			
			Iterator it=list.iterator();
			while(it.hasNext())
			System.out.println(it.next()+"\t ");
		
		
	}

}
}
