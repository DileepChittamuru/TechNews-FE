package collectionapi3;

import java.util.ArrayList;
import java.util.Scanner;

public class C {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter array size");
		int size=sc1.nextInt();
		int[] array = new int[size];
		System.out.println("array size is:"+array.length);
		
		ArrayList list=new ArrayList();
		ArrayList list1=new ArrayList();
	    
		try 
		{
					    	System.out.println("enter array elements:");
					        Scanner in = new Scanner(System.in); //Import java.util.Scanner for it
					        for (int j = 0; j < array.length ; j++)
					        {
					                int k = in.nextInt();
					                array[j] = k;
					                
					        }
					        
					        for(int k=0;k<array.length;k++)
					        {
					        	list.add(array[k]);
					     
					        }
					        System.out.println(list);
					       System.out.println("enter one num ");
					       int entered=sc1.nextInt();
					       int value=entered;
					       if(list.contains(entered))
					       {
					    	   list1.add(entered);
					    	   list1.add(entered+entered);
					    	   System.out.println(list1);
					    	   }
					       else{
					    	   System.out.println("Entered element not found");
					       }
					     
		
	     }
	     catch (Exception e) {
	            e.printStackTrace();
	     }
	}

}
