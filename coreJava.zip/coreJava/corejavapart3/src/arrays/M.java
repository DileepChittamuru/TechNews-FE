package arrays;

public class M {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x=new int[2];
		x[0]=10;
		Object obj=x;
		System.out.println(obj);
		int[] z=(int[])obj;
		z[1]=20;
		System.out.println("done");
		
	}

}
