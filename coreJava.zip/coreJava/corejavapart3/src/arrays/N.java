package arrays;

public class N {
public static void main(String[] args) {
	int[] x=new int[]{10,20,30,40};
	for(int i:x)
	{
		System.out.println(i);
	}
}
}
