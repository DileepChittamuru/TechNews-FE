package arrays;

public class I {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x=new int[2];
		int[] y=x;
		y[0]=1;
		x[1]=2;
		System.out.println(x[0]);
		System.out.println(y[1]);
	}
}
