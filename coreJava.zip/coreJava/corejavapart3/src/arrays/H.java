package arrays;

public class H {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		String[] x=new String[i];
		System.out.println("------");
		
		int[] y=new int[2];
		System.out.println(y);
		
	}

}
