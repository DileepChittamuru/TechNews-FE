package arrays;

public class K {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x=new int[2];
		int[] y=new int[3];
		x=y;
		y=x;
		System.out.println(y[0]);
		System.out.println(y[1]);
		System.out.println(y[2]);
		
	}

}
