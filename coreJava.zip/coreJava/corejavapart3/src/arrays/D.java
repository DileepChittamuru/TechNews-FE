package arrays;

public class D {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x=new int[2];
		int y[]=new int[2];
		int []z=new int[2];
		System.out.println("done");
	}

}
