package arrays;

public class P {
	P()
	{
		System.out.println("cons");
	}
	public static void main(String[] args)
	{
		new P();
		test(new int[]{10,20,30});
		
		}
		static void test(int[] x)
		{
			System.out.println(x.length);
			for(int i:x)
			{
			System.out.println(i);	
			}
		}
	}

