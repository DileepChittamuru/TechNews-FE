package arrays;

import java.util.Arrays;

public class S
{
public static void main(String[] args)
{
	String[] x={
			"xyz","abc","123","Abc","99"};
	
	System.out.println(Arrays.toString(x));
	Arrays.sort(x);
int s=	Arrays.binarySearch(x,"99");
System.out.println(s);
	System.out.println(Arrays.toString(x));
	}
}

