package arrays;

public class E {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x=new int[3];
		System.out.println(x[2]);
	}

}
