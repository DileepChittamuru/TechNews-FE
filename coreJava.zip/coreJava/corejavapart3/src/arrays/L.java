package arrays;

public class L {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		
		int[] x=new int[2];
		int[] y=x;
		Object obj=y;
		System.out.println(obj);
		int[] z=(int[])obj;
		System.out.println(z[0]);
		System.out.println(z[1]);
		System.out.println(y[0]);
		System.out.println(y[1]);
		System.out.println(x[0]);
		System.out.println(x[1]);
		
		}

}
