package arrays;

import java.util.Arrays;

public class T {
public static void main(String[] args) {
	int[] x={70,60,10,20,50,30,40};
	
	Arrays.sort(x);
	System.out.println(Arrays.toString(x));
	
	
	int i=Arrays.binarySearch(x,10);
	System.out.println(i);
	
	 i=Arrays.binarySearch(x,50);
	System.out.println(i);
	
	i=Arrays.binarySearch(x,70);
	System.out.println(i);
	
}
}
