package arrays;

public class F {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x=new int[4];
		System.out.println(x.length);
		System.out.println("=========");
		for(int i=0;i<x.length;i++)
		{
			System.out.println(x[i]);
		}
	}

}
