package arrays;

public class A {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		System.out.println(i);
		i=10;
		System.out.println(i);
		i=20;
		System.out.println(i);
	}

}
