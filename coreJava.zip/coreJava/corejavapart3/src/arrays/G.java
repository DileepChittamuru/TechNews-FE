package arrays;

public class G {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String x[]=new String[3];
		for(String s1:x)
		{
			System.out.println(s1);
		}
		
	}

}
