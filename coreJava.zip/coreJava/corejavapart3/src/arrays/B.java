package arrays;
import java.util.*;
public class B {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			int[] x=new int[2];
			x[0]=10;
			x[1]=20;
			System.out.println(x[0]);
			System.out.println(x[1]);
			System.out.println(Arrays.toString(x));
			
			String[] y=new String[3];
			y[0]="abc";
			y[1]="aaa";
			y[2]="999";
			System.out.println(y);
			
			Double[] z=new Double[3];
			z[0]=12.3;
			z[1]=233.33;
			z[2]=321.44;
			
			System.out.println(z);
			
			
	}

}
