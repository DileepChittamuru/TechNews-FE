package arrays;

import java.util.Arrays;

public class U {
public static void main(String[] args) {
	String[] s={
				"hello",
				"blue",
				"yellow",
				"white",
				"pink",
				"lara",
				"java"};
	Arrays.sort(s);
	System.out.println(Arrays.toString(s));
	int i=Arrays.binarySearch(s, "abc");
	System.out.println("abc:"+i);
	
	i=Arrays.binarySearch(s,"white");
	System.out.println("white:"+i);
	
	i=Arrays.binarySearch(s, "pink");
	System.out.println("pink:"+i);
	}
}

