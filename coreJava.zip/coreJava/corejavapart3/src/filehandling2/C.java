package filehandling2;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class C
{

	
	public static void main(String[] args) throws IOException
	{
	File f=new File("test.txt");
	FileReader in=new FileReader(f);
	long size=f.length();
	char[] x=new char[(int)size];
	in.read(x);
	in.close();
	String s1=new String(x);
	System.out.println(s1);
	

	}

}
