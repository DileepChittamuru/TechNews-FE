package filehandling2;

import java.io.FileWriter;
import java.io.IOException;

public class E {

	
	public static void main(String[] args) 
	{
		FileWriter out=null;
		try
		{
			out=new FileWriter("test.txt");
			out.write("hyderabad ka badsha and");
			System.out.println("done");
		}
		catch(IOException e)
		{
			e.printStackTrace();
			
		}
		finally
		{
			try
			{
				if(out!=null)
				{
					out.flush();
					out.close();
					out=null;
					
				}
			}
			catch(IOException e)
			{
				e.printStackTrace();
				
			}
		}

	}

}
