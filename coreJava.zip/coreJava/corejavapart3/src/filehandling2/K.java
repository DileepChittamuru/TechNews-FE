package filehandling2;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class K {

	
	public static void main(String[] args)throws IOException
	{
		File f=new File("C:/Users/Public/Pictures/Sample Pictures/Tulips.jpg");
		File f2=new File("test.jpg");
		FileInputStream fin=null;
		BufferedInputStream bin=null;
		FileOutputStream fout=null;
		BufferedOutputStream bout=null;
		
	
			fin=new FileInputStream(f);
			bin=new BufferedInputStream(fin);
			byte[] b=new byte[(int )f.length()];
			fin.read(b);
			
			fout=new FileOutputStream(f2);
			bout=new BufferedOutputStream(fout);
			bout.write(b);
			System.out.println("done");
			
			
		

	}

}
