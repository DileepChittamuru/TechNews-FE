package filehandling2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class G
{
	public static void main(String[] args) throws IOException
	{
	FileWriter out=new FileWriter("test.txt");
	BufferedWriter bout=new BufferedWriter(out);
	bout.write("hello dileep");
	bout.newLine();
	bout.write("hello akka");
	bout.newLine();
	bout.write("hello anna");
	bout.newLine();
	bout.write("hello amma");
	bout.flush();
	bout.close();
	System.out.println("done");

	}

}
