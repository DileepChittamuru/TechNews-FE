package filehandling2;

import java.io.FileWriter;
import java.io.IOException;

public class E1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		FileWriter out=null;
		try
		{
			out=new FileWriter("test.txt");
			out.write("dileep reddy\n hyderabad ka\n badsha");
			System.out.println("done");
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
			
		}
		finally
		{
			try
			{
				if(out!=null)
				{
				out.flush();
				out.close();
				out=null;
				}
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
		
	}

}
