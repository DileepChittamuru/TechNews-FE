package filehandling2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class M {

	/**
	 * @param args
	 */
	public static void main(String[] args)throws IOException
	{
		// TODO Auto-generated method stub
		FileWriter fout=new FileWriter("test.txt");
		BufferedWriter bout=new BufferedWriter(fout);
		bout.write("hello");
		bout.newLine();
		bout.write("genes");
		bout.flush();
		bout.close();
		fout.close();
		System.out.println("done");
	}

}
