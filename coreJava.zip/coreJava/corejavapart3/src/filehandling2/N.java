package filehandling2;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class N {

	
	public static void main(String[] args)throws IOException
	{
		// TODO Auto-generated method stub
		File f=new File("C:/Users/Dileep/Pictures/a.png");
		File f1=new File("pic.png");
		FileInputStream fin=new FileInputStream(f);
		BufferedInputStream bin=new BufferedInputStream(fin);
		FileOutputStream fout=new FileOutputStream(f1);
		BufferedOutputStream bout=new BufferedOutputStream(fout);
		
		byte b[]=new byte[(int)f.length()];
		bin.read(b);
		bout.write(b);
		System.out.println("done");
		bout.flush();
		bout.close();
		fout.close();
		fin.close();
		bin.close();
		
		
	}

}
