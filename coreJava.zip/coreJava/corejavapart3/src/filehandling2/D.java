package filehandling2;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class D {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
		File f=new File("test.txt");
		FileReader in=new FileReader(f);
		long size=f.length();
		char[] x=new char[(int)size];
		in.read(x);
		in.close();
		String s1=new String(x);
		System.out.println(s1);
		
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
	}

}
