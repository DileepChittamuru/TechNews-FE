package filehandling2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class A
{
	public static void main(String[] args) 
	{
		File f1=new File("test.txt");
		try
		{
		FileWriter out=new FileWriter(f1);
		out.write("abc\n");
		out.write("hello123\n");
		out.write("test");
		out.flush();
		out.close();
		
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
		System.out.println("done");

	}

}
