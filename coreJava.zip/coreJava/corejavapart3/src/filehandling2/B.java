package filehandling2;

import java.io.FileWriter;
import java.io.IOException;

public class B {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			FileWriter out=new FileWriter("test.txt");
			out.write("abcd\n");
			out.write("hello\n");
			out.flush();
			out.close();
			
			
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
		System.out.println("done");
	}

}
