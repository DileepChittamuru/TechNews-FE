package com.strings1;

public class A304 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="java";
		String s2="ja";
		String s3=s2+"va";
		System.out.println(s1);
		//System.out.println(s2);
		System.out.println(s3);
		System.out.println("===============");
		System.out.println(s1==s3);
		System.out.println(s1.equals(s3));
		System.out.println("===============");
		System.out.println("done");
	}

}
