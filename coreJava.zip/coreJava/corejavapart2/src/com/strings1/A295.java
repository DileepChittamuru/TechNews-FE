package com.strings1;

public class A295 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="abc";
		String s2="abc";
		String s3=new String("abc");
		String s4=new String("abc");
		
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		System.out.println(s4);
		System.out.println("=============");
		System.out.println(s1==s2);
		System.out.println(s1==s3);//compares address of object
		System.out.println(s2==s3);
		System.out.println(s3==s4);
	}

}
