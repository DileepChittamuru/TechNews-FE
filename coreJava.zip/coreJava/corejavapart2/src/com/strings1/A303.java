package com.strings1;

public class A303 {

	
	public static void main(String[] args)
	{
	String s1="java";
	String s2="ja"+"va";
	System.out.println(s1==s2);
	System.out.println("==============");
	System.out.println(s1.equals(s2));
	

	}

}
