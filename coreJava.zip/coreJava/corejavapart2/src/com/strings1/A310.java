package com.strings1;

public class A310 {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		String s1="ja";
		String s2="va";
		String s3=s1.concat(s2);
		String s4="java";
		System.out.println(s3==s4);
		System.out.println(s3.equals(s4));
	}

}
