package com.strings1;

public class A318 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="laratechnology";
		String s2=s1.substring(5);
		String s3=s1.substring(5,9);
		String s4=s2.intern();
		String s5=s1.intern();
	    boolean  s6=s1.isEmpty();
		System.out.println("s1:"+s1);
		System.out.println("==========================");
		System.out.println("s2:"+s2);//dispalays from 5 onwards
		System.out.println("============================");
		System.out.println("s3:"+s3);//displays from 5 to 9 not 9 ( 5,6,7,8)
		System.out.println("===============================");
		System.out.println("s4:"+s4);//copy s2 output
		System.out.println("================================");
		System.out.println("s6:"+s6);
		System.out.println("============================");
		String s="";
		boolean b=s.isEmpty();
		System.out.println(b);
	}

}
