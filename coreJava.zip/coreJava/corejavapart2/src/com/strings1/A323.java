package com.strings1;

public class A323 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="lara tech";
		System.out.println(s1.startsWith("lara"));
		System.out.println("===========");
		System.out.println(s1.startsWith("123"));
		System.out.println("==========");
		System.out.println(s1.endsWith("te"));
		System.out.println("==========");
		System.out.println(s1.endsWith("ch"));
		System.out.println("=============");
	}

}
