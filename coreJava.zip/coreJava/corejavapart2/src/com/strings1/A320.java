package com.strings1;

public class A320 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="abc123xyz123xyz";
		System.out.println(s1.codePointAt(0));//a's ascii value
		System.out.println("=======");
		System.out.println(s1.codePointAt(1));//b's ascii value
		System.out.println("======");
		System.out.println(s1.codePointCount(2, 10));//finds the difference
		System.out.println("========");
		System.out.println(s1.contains("ab"));//true
		System.out.println("========");
		System.out.println(s1.contains("prince"));//false
		System.out.println("==========");
		System.out.println(s1.replace('x','f'));//abc123fyz123fyz
		System.out.println("=======");
		System.out.println(s1.startsWith("abc"));//true 
		System.out.println("==============");
		System.out.println("done");//done
	}

}
