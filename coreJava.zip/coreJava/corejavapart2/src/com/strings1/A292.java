package com.strings1;

public class A292 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="abc";
		String s2="abc";
		System.out.println(s1);
		System.out.println(s2);
		
	}

}
