package com.strings1;

public class A294 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="lara";
		String s2=new String("rst");
		System.out.println(s1.toString());
		System.out.println(s2.toString());
		
	}

}
