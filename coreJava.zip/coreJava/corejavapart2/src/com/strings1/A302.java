package com.strings1;

public class A302 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Lara";
		System.out.println(s1);
		System.out.println("===============");
		String s2=s1+"technologies";
		System.out.println(s2);
		System.out.println("=============");
		String s3=s1.concat("technologies");
		System.out.println(s3);
		System.out.println("=============");
		System.out.println("done");
	}

}
