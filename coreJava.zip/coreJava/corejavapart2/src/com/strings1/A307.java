package com.strings1;

public class A307 {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
			System.out.println(2+4);
			System.out.println(2+"lara");
			System.out.println("lara"+null);
			System.out.println(2+4+"lara"+2+3+"dile"+3+2+null);
			System.out.println("lara"+2+4+null);
			//String s1=null;
			//s1=s1.concat("cdr");
			
			
	}

}
