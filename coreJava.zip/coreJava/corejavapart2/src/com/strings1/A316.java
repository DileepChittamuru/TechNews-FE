package com.strings1;

public class A316 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="abc123xyz";
		System.out.println(s1.length());
		System.out.println("===============");
		System.out.println(s1.charAt(0));
		System.out.println(s1.charAt(3));
		System.out.println(s1.charAt(9));
	}

}
