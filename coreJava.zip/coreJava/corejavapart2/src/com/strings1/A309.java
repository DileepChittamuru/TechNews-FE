package com.strings1;

public class A309 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="lara";
		System.out.println(s1);
		System.out.println("=========");
		s1=s1.concat("rst");
		System.out.println(s1);
		System.out.println("done");
	}

}
