package com.strings1;

public class A311 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="abc";
		System.out.println(s1.length());
	}

}
