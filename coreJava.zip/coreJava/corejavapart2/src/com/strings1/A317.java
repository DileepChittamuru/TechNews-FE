package com.strings1;

public class A317 {

	
	public static void main(String[] args)
	{
	String s1="a1b2c3x1y2x3";
	System.out.println(s1);
	System.out.println(s1.length());
	System.out.println(s1.indexOf('2'));//checks for 2
	System.out.println(s1.indexOf('x'));//checks for x
	System.out.println(s1.indexOf('x',8));//checks for x from 8th index onwards
	System.out.println(s1.indexOf('2',3));//checks for 2 from 3rd index onwards
	}

}
