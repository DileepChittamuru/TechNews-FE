package com.strings1;

public class A293 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="abc";
		s1="xyz";
		System.out.println(s1);
	}

}
