package com.strings1;

public class A300 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Lara";
		String s2="lara";
		System.out.println(s1.equals(s2));
		System.out.println("=========");
		System.out.println(s1.equalsIgnoreCase(s2));
	}

}
