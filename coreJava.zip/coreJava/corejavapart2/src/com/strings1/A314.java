package com.strings1;

public class A314 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1=" abc 123 xyz  ";
		System.out.println(s1.length());
		System.out.println(s1);
		s1=s1.trim();
		System.out.println(s1.length());
		System.out.println(s1);
	}

}
