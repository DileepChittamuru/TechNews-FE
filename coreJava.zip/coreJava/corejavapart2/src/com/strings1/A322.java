package com.strings1;

public class A322 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 ="hello dileep sir welcome to split method";
		String arr[]=s1.split(" ");
		for( String s2:arr)
		{
			System.out.println(s2);
		}
	}

}
