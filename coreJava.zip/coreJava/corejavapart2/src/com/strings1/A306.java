package com.strings1;

public class A306 {

	
	public static void main(String[] args)
	{
		String s1=null;
		System.out.println(s1);
		System.out.println("===========");
		
		s1=s1+s1+null;
		System.out.println(s1);
		System.out.println("done");
		String s2=s1.concat("null");
		System.out.println(s2);
		

	}

}
