package com.wrapper;

public class A89 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="true";
		String s2="abc";
		Boolean b1=new Boolean(s1);
		System.out.println(b1);
		Boolean b2=new Boolean(s2);
		System.out.println(s2);
	}

}
