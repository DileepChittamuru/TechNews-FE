package com.wrapper;

public class A92 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="10";
		
		int i=Integer.parseInt(s1);
		System.out.println(i);
		
		float f=Float.parseFloat(s1);
		System.out.println(f);
		
		double d=Double.parseDouble(s1);
		System.out.println(d);
		
		byte b=Byte.parseByte(s1);
		System.out.println(b);
	}

}
