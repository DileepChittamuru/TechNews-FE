package com.wrapper;

public class A84 {

	//================================================BOXING N UNBOXING======================================================
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//jdk1.5
		int i=10;
		Integer obj=i;
		int n=obj;
		System.out.println(n);
				
		//jdk 1.4
		int j=10;
		Integer obj1=new Integer(j);
		int k=obj1.intValue();
		System.out.println(k);
		System.out.println("=========================================================");
		
		//jdk 1.4
		double d=10.09;
		Double obj2=new Double(d);
		double d1=obj2.doubleValue();
		System.out.println(d1);
		
		//jdk 1.5
		double d2=10.09;
		Double obj3=d2;
		double d3=obj3;
		System.out.println(d3);
		System.out.println("===============================================================");

		//jdk 1.4 
		char c='a';
		Character obj4=new Character(c);
		char c2=obj4.charValue();
		System.out.println(c2);
		
		//jdk 1.5
		char c1='b';
		Character obj5=c1;
		char c22=obj5;
		System.out.println(c22);
		System.out.println("==============================================================");
		
		
		//jdk 1.4
		String s1="10";
		Integer i1=new Integer(s1);
		Integer i2=Integer.valueOf(s1);
		int i22=i1.intValue();
		System.out.println(i22);
		
		
		//jdk1.4
		Long l1=new Long(s1);
		long l2=l1.longValue();
		System.out.println(l2);
		System.out.println("================================================================");
		
		
		//jdk 1.4
		Byte b=new Byte(s1);
		byte b1=b.byteValue();
		System.out.println(b1);
		System.out.println("=================================================================");
		
		
		
		
	}

}
