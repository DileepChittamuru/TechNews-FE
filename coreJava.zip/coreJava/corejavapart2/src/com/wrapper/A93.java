package com.wrapper;

public class A93 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=90;
		double d=10.09;
		byte b=10;
		System.out.println("=========================");
		System.out.println(i);
		System.out.println(d);
		System.out.println(b);
		System.out.println("========================");
		String s1=Integer.toString(i);
		String s2=Double.toString(d);
		String s3=Byte.toString(b);
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		System.out.println("=========================");
		
	}

}
