package com.rough;

public class A99
{
	int test1()
	{
		try
		{
			
		}
		catch(ArithmeticException e1)
		{
			
		}
		finally
		{
			return 3;
		}
	}
	//====================================================================================
	int test2()
	{
		try
		{
			
		}
		catch(ArithmeticException e1)
		{
			
		}
		finally
		{
			
		}
		return 4;
	}
	//=====================================================================================
	int test3()
	{
		try
		{
			return 1;
		}
		catch(ArithmeticException e1)
		{
		
		}
		finally
		{
			
		}
		return 3;
	}
	//============================================================================================
	int test4()
	{
		
		try
		{
			return 1;
		}
		catch(ArithmeticException e1)
		{
			return 2;
		}
		finally
		{
			
		}
		
	}
	//=================================================================================================
	int test5()
	{
		try
		{
			return 1;
		}
		catch(ArithmeticException e1)
		{
			return 2;
		}
		finally
		{
			return 3;
			
		}
	}
	//=================================================================================================
	int test6()
	{
		try
		{
			
		}
		catch(ArithmeticException e1)
		{
			return 2;
		}
		finally
		{
			return 3;
		}
	}
	//======================================================================================================

}

