package com.rough;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class DILEEP
{
	public static void main(String[] args) {
		/*HashMap map=new HashMap();
		map.put(1,"abc");
		map.put(2,"def");
		map.put(3, "cdr");*
		*/
		Hashtable table=new Hashtable();
		table.put(1,"abc");
		table.put(2, "cde");
		table.put(3,"ghi");
		Enumeration e1=table.elements();
		table.put(4,"cdr");
		while(e1.hasMoreElements())
		{
			System.out.println(e1.nextElement());
		}
	
		
	}
}
