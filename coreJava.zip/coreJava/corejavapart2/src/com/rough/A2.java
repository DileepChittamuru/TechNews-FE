package com.rough;

public class A2 {

	static
	{
		class B2
		{
			
		}
		/*static class S1
		{
			
		}*/
		
	}
	{
		class C3
		{
			
		}
		/*static class S2
		{
			
		}*/
	}
	A2()
	{
		class D4
		{
			
		}
		/*static class S3
		{
			
		}*/
	}
	void test1()
	{
		/*static class S6
		{
			
		}*/
	}
	public static void main(String[] args) 
	{
		class A
		{
			
		}
		/*static class S4
		{
			
		}*/
		
	}

}
