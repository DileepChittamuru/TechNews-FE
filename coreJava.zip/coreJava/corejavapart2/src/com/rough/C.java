package com.rough;
class B
{
	public void Exception()
	{
		System.out.println("B -exception");
	}
}
public class C extends B
{
	public static void main(String[] args)
	{
		try
		{
			new C().Exception();
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
			
	}
	public void Exception()throws RuntimeException
	{
		super.Exception();
		System.out.println("C-exception");
		
	}
}
