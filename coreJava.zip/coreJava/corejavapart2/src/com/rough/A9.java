package com.rough;

public class A9
{
	int test1()
	{
		try
		{
			
		}
		catch(ArithmeticException e1)
		{
			
		}
		catch(NumberFormatException e2)
		{
			
		}
		return 4;
	}
	int test2()
	{
		try
		{
			return 1;
		}
		catch(ArithmeticException e1)
		{
			return 2;
		}
		catch(NumberFormatException e2)
		{
			
		}
		return 4;
	}
	int test3()
	{
		try
		{
			
		}
		catch(ArithmeticException e1)
		{
			return 2;
		}
		catch(NumberFormatException e2)
		{
			return 3;
		}
		return 4;
	}
	int test4()
	{
		try
		{
			return 1;
		}
		catch(ArithmeticException e1)
		{
			return 2;
			
		}
		catch(NumberFormatException e2)
		{
			
		}
		return 4;
	}
	int test5()
	{
		try
		{
			return 1;
		}
		catch(ArithmeticException e1)
		{
			return 2;
		}
		catch(NumberFormatException e2)
		{
			return 3;
		}
		
	}
}
