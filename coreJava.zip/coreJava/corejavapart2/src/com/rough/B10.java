package com.rough;
class A10
{
	void test()throws ClassNotFoundException
	{
		System.out.println("done");
	}
}
public class B10 extends A10 {

	/**
	 * @param args
	 */
	void test()throws NumberFormatException,NullPointerException
	{
		System.out.println("done2");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
B10 b=new B10();
b.test();

	}

}
