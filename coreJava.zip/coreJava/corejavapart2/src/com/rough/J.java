package com.rough;

public class J {

	
	public void process() 
	{ 
		System.out.print("A,");
	}
	public static void main(String[] args) 
	{
		try 
		{
			new K().process(); 
		}
		catch (Exception e)
		{
			System.out.println("Exception"); 
		}
	}


}
class K extends J
{
	public void process() 
	{ 
		System.out.print("B,");
	}	
}
