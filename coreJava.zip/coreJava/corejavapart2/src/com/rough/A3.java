package com.rough;

public class A3 {

	/**
	 * @param args
	 */
	class B3
	{
		int i=90;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	A3 a=new A3();
	A3.B3 b=a.new B3();
	System.out.println(b.i);
		
	}

}
