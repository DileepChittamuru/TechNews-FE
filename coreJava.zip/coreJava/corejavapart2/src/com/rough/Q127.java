package com.rough;

public class Q127 extends Thread
{
	public static void main(String[] args) 
	{
		
		Q127 q=new Q127();
		q.start();
		System.out.println("done");
		//q.start();
		new Q127().start();
		new Q127().start();
		
	}
	public void run()
	{
		System.out.println("run");
		System.out.println("run");
		System.out.println("run");
		System.out.println("run");
		System.out.println("run");
		System.out.println("run");
	}
	
}
