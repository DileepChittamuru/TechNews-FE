package com.rough;

public class Threadtest extends Thread
{
	public void run() 
    { 
        System.out.println("In run"); 
        yield(); 
        System.out.println("Leaving run"); 
    } 
    public static void main(String []argv) 
    { 
      Threadtest t=new Threadtest();
      Thread x=new Thread(t);
      x.start();
    } 
}
