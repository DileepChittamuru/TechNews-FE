package com.rough;

public class A8 
{
	int test1()
	{
		try
		{
			
		}
		catch(ArithmeticException e1)
		{
			
		}
		return 2;
		
	}
	int test2()
	{
		try
		{
			return 2;
		}
		catch(ArithmeticException e1)
		{
			return 3;
		}
	}
	int test3()
	{
		try
		{
			return 1;
		}
		catch(ArithmeticException e1)
		{
			
		}
		return 3;
	}
	int test4()
	{
		try
		{
			
		}
		catch(ArithmeticException e1)
		{
			return 2;
		}
		return 3;
	}
}
