package com.rough;

public class A {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			
			int i=Integer.parseInt("abc");
		}
		catch (ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		catch (Exception ex) 
		{
			System.out.println(ex);
		}
		

		
		
	}

}
