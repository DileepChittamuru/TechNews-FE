package com.rough;

public class A1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		 final int i=10;
		// static int j=20;
		//public int k=20;
		 //private int s=90;
		 
	}

}
