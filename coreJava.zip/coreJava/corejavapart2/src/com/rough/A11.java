package com.rough;
class AZ
{
	public void Exception()
	{
		System.out.println("jfh");
	}
}
public class A11 {

}
