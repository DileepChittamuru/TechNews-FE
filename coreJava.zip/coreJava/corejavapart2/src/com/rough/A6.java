package com.rough;

public class A6 extends Thread implements Runnable
{
	public void run()
	{
		System.out.println("done");
	}
	
	
	public static void main(String[] args)throws Exception
{
		// TODO Auto-generated method stub
		A6 a=new A6();
		a.start();
		Thread t1=new Thread();
		sleep(1000);
		System.out.println("dile");
		
		
	}

}
