package com.rough;

public class A5 {

	/**
	 * @param args
	 */
	
		// TODO Auto-generated method stub
		public static void main(String[] args) 
		{
			try
			{
				
			}
			finally
			{
				
			}
			
		}
		

	}


