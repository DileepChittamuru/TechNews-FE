package com.Strings3;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class A363 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String src=" abc 123 sd abcd 123 try   ";
		String exp="[ ]";
		Pattern p1=Pattern.compile(exp);
		Matcher m1=p1.matcher(src);
		int i=0;
		while(m1.find())
		{
			
			System.out.println(i++);
		}
				
	}

}
