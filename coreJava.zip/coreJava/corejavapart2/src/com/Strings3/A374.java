package com.Strings3;

public class A374 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			String src="a1b2c3d4e5f";
			String s[]=src.split("[0-5]");
			for(String x:s)
			{
				System.out.println(x);
			}
			System.out.println("=================");
			String s1[]=src.split("[a-f]");
			for(String z:s1)
			{
				System.out.println(z);
			}
	}

}
