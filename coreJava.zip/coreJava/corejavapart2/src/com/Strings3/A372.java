package com.Strings3;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class A372 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String src=" a1 b2 c3 d4 z9";
		String exp="\\s";
		Pattern p1=Pattern.compile(exp);
		Matcher m1=p1.matcher(src);
		while(m1.find())
		{
			System.out.println(m1.start()+":"+m1.group());
		}
	}

}
