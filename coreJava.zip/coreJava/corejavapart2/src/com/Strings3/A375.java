package com.Strings3;

import java.util.StringTokenizer;

public class A375 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String src="hello dileep reddy welcome to pidurupalem";
		StringTokenizer str=new StringTokenizer(src);
		while(str.hasMoreElements())
		{
			System.out.println(str.nextElement());
		}
		System.out.println("==============");
		String s1[]=src.split(" ");
		for(String x:s1)
		{
			System.out.println(x);
		}
	
	}

}
