package com.Strings3;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class A358
{
	public static void main(String[] args)
	{
		String s1="abcabababac";
		String exp="[ab]";
		Pattern p1=Pattern.compile(exp);
		Matcher m1=p1.matcher(s1);
		while(m1.find())
		{
			System.out.println(m1.start()+":"+m1.group());
		}
	}
}
