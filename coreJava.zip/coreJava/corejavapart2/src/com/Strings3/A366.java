package com.Strings3;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class A366 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String src="abcxyz1pqr2km9rst";
		Pattern p=Pattern.compile("[a-ep-z1-35-9]");
		Matcher m=p.matcher(src);
		while(m.find())
		{
			System.out.println(m.start()+":"+m.group());
		}
	}

}
