package com.Strings3;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class A367 {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		String src="a1b2c3h4z9";
		Pattern p=Pattern.compile("\\d");
		Matcher m=p.matcher(src);
		while(m.find())
		{
			System.out.println(m.start()+":"+m.group());
		}
	}

}
