package com.Strings3;

import java.util.StringTokenizer;

public class A376 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String src="helo dileep redyy,welcome to singapoor,what u need sir";
		StringTokenizer st=new StringTokenizer(src);
		while(st.hasMoreElements())
		{
			System.out.println(st.nextElement());
		}
		System.out.println("=========================");
		StringTokenizer st1=new StringTokenizer(src,",");
		while(st1.hasMoreElements())
		{
			System.out.println(st1.nextElement());
		}
		System.out.println("==========================");
		String s[]=src.split(",");
		for(String s1:s)
		{
			System.out.println(s1);
		}
	}

}
