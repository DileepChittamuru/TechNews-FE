package com.Strings3;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class A355 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String src="abcababcababc";
		String exp="a";
		Pattern p1=Pattern.compile(exp);
		Matcher m1=p1.matcher(src);
		while(m1.find())
		{
			System.out.println(m1.start()+":"+m1.group());
		}
	}

}
