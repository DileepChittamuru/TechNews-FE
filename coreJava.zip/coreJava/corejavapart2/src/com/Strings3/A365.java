package com.Strings3;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class A365 
{
	public static void main(String[] args)
	{
		String s="1234abcdef234cdefg";
		Pattern p=Pattern.compile("[a-b0-3]");
		Matcher m1=p.matcher(s);
		while(m1.find())
		{
			System.out.println(m1.start()+":"+m1.group());
		}
	}

}
