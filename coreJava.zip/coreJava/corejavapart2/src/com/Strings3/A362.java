package com.Strings3;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class A362 
{
	public static void main(String[] args)
	{
			String src="a1b2c3a1b2c3";
			Pattern p1=Pattern.compile("[1234]");
			Matcher m1=p1.matcher(src);
			while(m1.find())
			{
				System.out.println(m1.start()+":"+m1.group());
			}
			
	}

}
