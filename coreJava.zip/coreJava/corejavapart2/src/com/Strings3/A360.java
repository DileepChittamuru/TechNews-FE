package com.Strings3;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class A360 {

	
	public static void main(String[] args) 
	{
		String s1="hello";
		String s2="hello";
		Pattern p1=Pattern.compile(s2);
		Matcher m1=p1.matcher(s1);
		while(m1.find())
		{
			System.out.println("both are equal");
		}

	}

}
