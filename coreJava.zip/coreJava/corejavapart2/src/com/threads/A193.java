package com.threads;

public class A193 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<1000;i++)
		{
			System.out.println(i);
		}
		for(int i=1000;i<2000;i++)
		{
			System.out.println(i);
		}
	}

}
