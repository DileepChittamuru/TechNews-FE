package com.threads;

public class A204 {
	static class A extends Thread
	{
		public void run()
		{
			for(int i=0;i<1000;i++)
			{
				System.out.println(i);
			}
		}
	}
	static class B implements Runnable
	{

		@Override
		public void run() {
			// TODO Auto-generated method stub
			for(int i=1000;i<2000;i++)
			{
				System.out.println(i);
			}
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a1=new A();
		a1.start();
		
		B b1=new B();
		Thread t1=new Thread(b1);
		t1.start();
		
		for(int i=2000;i<3000;i++)
		{
			System.out.println(i);
		}
	}

}
