package com.threads;
class F extends Thread
{
	public void run()
	{
		for(int i=0;i<1000;i++)
		{
			System.out.println(i);
			start();
		}
	}
}
public class A200 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		F f=new F();
		f.start();
		for(int i=1000;i<2000;i++)
		{
			System.out.println(i);
		}
	}

}
