package com.threads;

class B extends Thread
{
	public void run()
	{
		for(int i=0;i<4000;i++)
		{
			System.out.println(i);
		}
	}
}
public class A196 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B b=new B();
		b.start();
		System.out.println("done");
	}

}
