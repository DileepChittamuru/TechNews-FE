package com.threads;
class G  extends Thread
{
	public void run()
	{
		for(int i=0;i<1000;i++)
		{
			System.out.println(i);
		}
	}
	void getStart()
	{
		start();
	}
}
public class A201 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		G g1=new G();
		g1.getStart();
		
		for(int i=1000;i<2000;i++)
		{
			System.out.println(i);
		}
	}

}
