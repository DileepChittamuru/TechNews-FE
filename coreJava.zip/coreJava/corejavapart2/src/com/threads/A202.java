package com.threads;
class H extends Thread
{
	H()
	{
		start();
		
	}
	public void run()
	{
		for(int i=0;i<1000;i++)
		{
			System.out.println(i);
		}
	}
}
public class A202 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		H h=new H();
		for(int i=1000;i<2000;i++)
		{
			System.out.println(i);
		}
	}

}
