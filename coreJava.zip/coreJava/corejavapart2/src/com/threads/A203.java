package com.threads;
class I extends Thread
{
	public void run()
	{
		for(int i=0;i<1000;i++)
		{
			System.out.println(i);
		}
	}
}
public class A203 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
I i1=new I();
i1.run();
i1.start();
System.out.println("done");
	}

}
