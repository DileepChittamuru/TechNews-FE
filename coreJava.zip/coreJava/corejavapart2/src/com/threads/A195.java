package com.threads;
class ThreadA extends Thread
{
	public void run()
	{
		for(int i=0;i<1000;i++)
		{
			System.out.println(i);
		}
	}
}
class ThreadB extends Thread
{
	public void run()
	{
		for(int i=1000;i<2000;i++)
		{
			System.out.println(i);
		}
	}
}
public class A195 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadA t1=new ThreadA();
		t1.start();
		ThreadB t2=new ThreadB();
		t2.start();
		//t2.setDaemon(true);
		
		for(int i=2000;i<3000;i++)
		{
			System.out.println(i);
		}
	}

}
