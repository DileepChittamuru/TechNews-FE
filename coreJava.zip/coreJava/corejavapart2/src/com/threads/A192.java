package com.threads;

public class A192 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.out.println(1);
			test();
			System.out.println(2);
	}
	static void test()
	{
		System.out.println(3);
		System.out.println(4);
	}

}
