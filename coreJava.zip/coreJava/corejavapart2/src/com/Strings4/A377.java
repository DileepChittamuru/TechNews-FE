package com.Strings4;

import java.util.Date;

public class A377 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date date=new Date();
		long time=date.getTime();
		
		System.out.println(date);
		System.out.println(time);
	}

}
