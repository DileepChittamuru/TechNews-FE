package com.Strings4;

import java.util.Date;

public class A383 {

	
	public static void main(String[] args)
	{
		Date date=new Date(1000*60);
		long time=date.getTime();
		System.out.println(date);
		System.out.println(time);
		

	}

}
