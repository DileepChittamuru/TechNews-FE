package com.Strings4;

import java.util.Date;

public class A384 {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		Date date=new Date(1000*60*6);
		long time=date.getTime();
		System.out.println(time);
		System.out.println(date);
		
	}

}
