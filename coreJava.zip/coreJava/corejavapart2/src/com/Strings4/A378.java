package com.Strings4;

import java.util.Date;

public class A378 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Date date=new Date(0);
			System.out.println(date);
	}

}
