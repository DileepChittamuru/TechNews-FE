package com.innerclasses;

public class A58 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A53 a=new A53();
		A53 a1=new A53(){
			
			void test1()
			{
				System.out.println("overdided A53-test1");
			}
			void test2()
			{
				System.out.println("overidede A53-test2");
			}
		};
		a.test1();
		a.test2();
		a1.test1();
		a1.test2();
		System.out.println("hello world");
	}

}
