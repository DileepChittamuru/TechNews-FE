package com.innerclasses;

public class Cmdlinargs1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(String s1:args)
		{
			System.out.println(s1);
			
		}
		
	}

}
