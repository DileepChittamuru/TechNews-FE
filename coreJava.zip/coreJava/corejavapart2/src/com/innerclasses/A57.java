package com.innerclasses;

public class A57 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A53 a=new A53()
		{
			void test1()
			{
				System.out.println("overided a53-test1");
			}
		};
		a.test1();
		a.test2();
	}

}
