package com.innerclasses;
//static members are universal...................................
//static methods incorporates only static members.................
//non-static methods incorporates static n non static members....................
public class A36 
{
	int i;
	static int j;
	void test1()
	{
		i=20;
		j=30;
		System.out.println(i);
		System.out.println(j);
		test1();
		test2();
	}
	static void test2()
	{
		j=40;
		System.out.println(j);
		test2();
		
	}
	
}
