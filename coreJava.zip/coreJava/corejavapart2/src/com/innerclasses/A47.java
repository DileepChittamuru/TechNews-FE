package com.innerclasses;

public class A47 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
	}

}
