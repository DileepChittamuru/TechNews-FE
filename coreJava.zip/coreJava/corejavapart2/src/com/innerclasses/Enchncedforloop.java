package com.innerclasses;

public class Enchncedforloop {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x[]={1,2,3,4,5,6};
		for(int i:x)
		{
			System.out.println(i);
		}
	}

}
