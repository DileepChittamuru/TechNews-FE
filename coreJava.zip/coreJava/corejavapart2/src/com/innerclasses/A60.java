package com.innerclasses;

public class A60 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A54 a=new A54() {
			
			@Override
			void test1() {
				// TODO Auto-generated method stub
				System.out.println("A54-test2()");
			}
		};
		a.test1();
		a.test2();
		
	}

}
