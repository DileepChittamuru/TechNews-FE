package com.innerclasses;

public class A50 {

	
	static
	{
		class B50
		{
			
		}
	}
	{
		class B50
		{
			
		}
	}
	A50()
	{
		class B50
		{
			
		}
	}
	void test()
	{
		class B50
		{
			
		}
	}
	static void test1()
	{
		class B50
		{
			
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		class B50
		{
			
		}
		System.out.println("helloworld");
	}

}
