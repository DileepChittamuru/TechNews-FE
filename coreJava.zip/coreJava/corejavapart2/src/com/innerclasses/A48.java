package com.innerclasses;

public class A48 {

	/**
	 * @param args
	 */
	static void test()
	{
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
		System.out.println("99999999999999999");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("================");
		test();
		System.out.println("================");
		test();
		System.out.println("================");
		test();
		System.out.println("================");

	}

}
