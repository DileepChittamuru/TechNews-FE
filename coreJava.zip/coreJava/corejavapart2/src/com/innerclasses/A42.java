package com.innerclasses;

public class A42
	{
			int i;
			static int j;
			void test1()
			{
				i=1;
				j=2;
				test1();
				B42 b42=new B42();
				C42  c42=new C42();
				A42 a=new A42();
				
			}
			static void test2()
			{
				j=3;
				test2();
				C42 c42=new C42();
				A42 a=new A42();
			}
	class B42
	{
		int m;
		void test3()
		{
			m=20;
			System.out.println(m);
			i=1;
			j=2;
			System.out.println(i);
			System.out.println(j);
			test1();
			test2();
			test3();
			B42 b=new B42();
			C42 c=new C42();
			A42 a=new A42();
		}
		
	}
	static class C42
	{
		int n;
		static int o;
		void test4()
		{
			n=2;
			o=3;
			j=2;
			System.out.println(n);
			System.out.println(o);
			System.out.println(j);
			test2();
			test5();
			C42 c=new C42();
		    
			
			
			
		}
		static void test5()
		{
			o=5;
			System.out.println(o);
			j=2;
			System.out.println(j);
			test5();
			test2();
			C42 c=new C42();
		}
	}
}
