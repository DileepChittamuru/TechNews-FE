package com.innerclasses;

public class A52 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		class B52
		{
			//static int i;
			int j;
			void test()
			{
				j=2;
				System.out.println(j);
			}
			
			
		
		}
		System.out.println("hello world");
	}

}
