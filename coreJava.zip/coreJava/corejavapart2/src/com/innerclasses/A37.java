package com.innerclasses;
//3 .class files will generarte here
public class A37
{

	class B37
	{
		
	}
	class C37
	{
		
	}
}
