package com.innerclasses;

public class A49 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		class B49
		{
			void test()
			{
				System.out.println("99999999999999999");
				System.out.println("99999999999999999");
				System.out.println("99999999999999999");
				System.out.println("99999999999999999");
			}
		}
		B49 b=new B49();
		System.out.println("*************************");
		b.test();
		System.out.println("*************************");
		b.test();
		System.out.println("*************************");
		b.test();
		System.out.println("*************************");
		
	}

}
