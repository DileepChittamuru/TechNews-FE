package com.innerclasses;

public class A66 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A54 a=method1();
		A55 b=method2();
		a.test1();
		a.test2();
		b.test1();
		b.test2();
	}
	static A54 method1()
	{
		A54 a=new A54() {
			
			@Override
			void test1() {
				// TODO Auto-generated method stub
				System.out.println("test1");
			}
		};
		return a;
	}
	static A55 method2()
	{
		return new A55() {
			
			@Override
			public void test2() {
				// TODO Auto-generated method stub
				System.out.println("test2");
			}
			
			@Override
			public void test1() {
				// TODO Auto-generated method stub
				System.out.println("test2");
			}
		};
	}

}
