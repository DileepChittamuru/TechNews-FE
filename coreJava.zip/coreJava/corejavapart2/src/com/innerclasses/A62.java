package com.innerclasses;

public class A62 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A54 a=new A54() {
			
			@Override
			void test1() {
				// TODO Auto-generated method stub
				System.out.println("test1");
			}
			void test2()
			{
				System.out.println(" overided -test2");
			}
		};
		a.test1();
		a.test2();
	}

}
