package com.innerclasses;

public class A44 
{
	int i;
	static int j;
	
	class B44
	{
		int p;
		
		void test1()
		{
			System.out.println("test1 begin");
			i=2;
			p=2;
			j=3;
			
			System.out.println(i);
			System.out.println(p);
			System.out.println(j);
			System.out.println("test1 end");
		}
		
		
	}
	static class C44
	{
		int q;
		static int r;
		void test2()
		{
		
			System.out.println("test2 begin");
			q=2;
			r=3;
			System.out.println(q);
			System.out.println(r);
			j=4;
			System.out.println(j);
			test3();
			System.out.println("test2 end");
			
			
	
		}
	static 	void test3()
		{
		System.out.println("test3 start");
			r=2;
			j=5;
			System.out.println(r);
			System.out.println(j);
	   System.out.println("test3 end");
			
		}
	}
	
	public static void main(String[] args)
	{
		A44 a=new A44();
		C44 c=new C44();
		A44.B44 b=a.new B44();
		
		b.test1();
		c.test2();
		c.test3();
		

	}

}
