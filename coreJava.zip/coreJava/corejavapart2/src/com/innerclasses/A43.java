package com.innerclasses;

public class A43 
{
	class B43
	{
		
	}
	static class C43
	{
		
	}
	
	public static void main(String[] args)
	{
		A43 a=new A43();
		//B43 b=new B43();
		C43 c=new C43();
		A43.B43 b=null;
		b=a.new B43();
	}

}
