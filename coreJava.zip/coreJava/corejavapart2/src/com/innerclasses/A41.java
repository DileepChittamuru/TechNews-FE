package com.innerclasses;

public class A41
{
	static class B41
	{
				int i;
				static int j;
				void test1()
				{
					i=3;
					j=5;
					System.out.println(i);
					System.out.println(j);
					test1();
					test2();
				}
				static void test2()
				{
					j=3;
					System.out.println(j);
					test2();
				}
	}
}
