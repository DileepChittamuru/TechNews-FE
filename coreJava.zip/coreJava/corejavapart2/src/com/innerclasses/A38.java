package com.innerclasses;
//static members are universal
//static methods incorporates only static members..............
public class A38
{
class C38
{
	
}
static class D38
{
	
}
void test1()
{
	C38 c=new C38();
	D38 d=new D38();
}
static void test2()
{
	D38 d1=new D38();
}
}
