package com.innerclasses;

import java.util.Scanner;

public class Scanner1 {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter some thing ");
		String s1=sc.next();
		System.out.println("you have enterd :"+s1);
	}

}
