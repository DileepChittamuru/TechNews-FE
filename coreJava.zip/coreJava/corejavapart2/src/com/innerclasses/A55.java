package com.innerclasses;

public interface A55 
{
void test1();
void test2();
}
