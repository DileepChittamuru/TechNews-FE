package com.innerclasses;

public class A56 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A53 a=new A53();
		System.out.println("main begin");
		a.test1();
		a.test2();
		System.out.println("main end");
		

	}

}
