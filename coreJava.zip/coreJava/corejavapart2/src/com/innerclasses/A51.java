package com.innerclasses;

public class A51 
{

	public static void main(String[] args)
	{
		int i=10;
		final int j=20;
		class B51
		{
			void test()
			{
				//System.out.println(i);
				System.out.println(j);
			}
		}
		B51 b=new B51();
		System.out.println("==============");
		b.test();
		System.out.println("=================");
	}

}
