package com.innerclasses;

public class A40 
{
		class B40
		{
			int i;
			void test1()
			{
				
			}
			
		}
}
