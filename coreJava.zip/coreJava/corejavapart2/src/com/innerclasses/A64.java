package com.innerclasses;

public class A64 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			A55 a=new A55()
		     {
				public void test1()
				{
					System.out.println("test1");
				}
				public void test2()
				{
					System.out.println("test2");
				}
			 };
			 a.test1();
			 a.test2();
			
			
	}

}
