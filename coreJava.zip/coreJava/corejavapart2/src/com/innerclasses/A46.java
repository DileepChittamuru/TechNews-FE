package com.innerclasses;

public class A46 
{
		static void test()
		{
			class B46
			{
				int i=20;
			}
			B46 b=new B46();
			System.out.println(b.i);
			b.i=40;
			System.out.println(b.i);
			
		}

	
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		test();
		System.out.println("main end");
	}

}
