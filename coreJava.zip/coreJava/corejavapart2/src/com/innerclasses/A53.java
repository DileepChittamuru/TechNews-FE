package com.innerclasses;

public class A53 {
	void test1()
	{
		System.out.println("A53-test1");
	}
	void test2()
	{
		System.out.println("A53-test2");
	}

}
