package com.innerclasses;

public class A39
{
int i;
static int j;
class B39
{
	
}
static class C39
{
	
}
void test1()
{
	i=2;
	j=3;
	B39 b=new B39();
	C39 c=new C39();
	test1();
	test2();
	
}
static void test2()
{
	j=2;
	C39 c=new C39();
	test2();
	
}
}
