package com.innerclasses;

abstract public  class A54
{
	abstract void test1();
	void test2()
	{
		System.out.println("B-test2");
	}
}
