package com.innerclasses;

public class A65 {

	static void method1(A54 a)
	{
		a.test1();
		a.test2();
	}
	static void method2(A55 a1)
	{
		a1.test1();
		a1.test2();
	}
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		A54  a=new A54() {
			
			@Override
			void test1() {
				// TODO Auto-generated method stub
				System.out.println("test1-A53");
			}
		};
		method1(a);
		System.out.println("=====================");
		
		A55 a1=new A55() {
			
			@Override
			public void test2() {
				// TODO Auto-generated method stub
				System.out.println("test a55");
			}
			
			@Override
			public void test1() {
				// TODO Auto-generated method stub
				System.out.println("test2 a55");
			}
		};
		method2(a1);
		System.out.println("====================");
		method1(new A54() {
			
			@Override
			void test1() {
				// TODO Auto-generated method stub
				System.out.println("test1 argument type");
			}
		});
		method2(new A55() {
			
			@Override
			public void test2() {
				// TODO Auto-generated method stub
				System.out.println("argument test1()");
			}
			
			@Override
			public void test1() {
				// TODO Auto-generated method stub
				System.out.println("argument test2()");
			}
		});
		
	}

}
