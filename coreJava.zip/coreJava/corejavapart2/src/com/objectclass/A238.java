package com.objectclass;
class A
{
	int i;
}
public class A238 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a1=new A();
		a1.i=20;
		System.out.println(a1);
		System.out.println(a1.i);
	}

}
