package com.objectclass;
class D2
{
	int i;
}
public class A268 implements Cloneable
{
	D2 d1;
	int j;
	public static void main(String[] args)throws CloneNotSupportedException
	{
		A268 a=new A268();
		a.d1=new D2();
		a.d1.i=20;
		a.j=30;
		
		A268 a2=(A268)a.clone();
		System.out.println(a.d1.i);
		System.out.println(a.j);
		a2.d1.i=50;
		a2.j=30;
		System.out.println(a2.d1.i);
		System.out.println(a2.j);
		System.out.println(a.d1.i);
		System.out.println(a.j);
		
		
		

	}

}
