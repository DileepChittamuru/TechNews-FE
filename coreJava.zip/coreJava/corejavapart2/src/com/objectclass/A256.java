package com.objectclass;
class L1
{
	int i;
}
class M1 
{
	int i;
	
	public String toString()
	{
		return "i:"+i;
	}
	public boolean equals(Object obj)
	{
		M1 myobj=(M1)obj;
		return this.i==myobj.i;
	}
	
}

public class A256 {

	
	public static void main(String[] args) 
	{
	L1 obj1=new L1();
	L1 obj2=new L1();
M1 obj3=new M1();
M1 obj4=new M1();
	
	obj1.i=10;
	obj2.i=10;
	obj3.i=10;
	obj4.i=10;
	System.out.println(obj1);
	System.out.println(obj2);
	System.out.println(obj3);
	System.out.println(obj4);
	
	System.out.println(obj1.equals(obj2));
	System.out.println(obj2.equals(obj3));
	System.out.println(obj3.equals(obj4));
	System.out.println(obj4.equals(obj1));
			
	}

}
