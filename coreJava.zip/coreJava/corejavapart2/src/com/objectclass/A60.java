package com.objectclass;
class T
{
	int i;
	T(int i)
	{
		this.i=i;
	}
}
public class A60 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		T t1=new T(10);
		T t2=t1;
		System.out.println(t1);
		System.out.println(t2);
		System.out.println(t1.equals(t2));
		System.out.println(t1.hashCode());
		System.out.println(t2.hashCode());
		
	}

}
