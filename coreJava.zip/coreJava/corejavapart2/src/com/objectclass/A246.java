package com.objectclass;
class L
{
	int i;
	L(int i)
	{
		this.i=i;
	}
	public String toString()
	{
		return "i:"+i;
	}
}
class M extends L
{
	int j;
	M(int i,int j)
	{
		super(i);
		this.j=j;
		
	}
	public String toString()
	{
		return super.toString()+":"+"j:"+j;
	}
}
public class A246 {

	
	public static void main(String[] args)
	{
		L l1=new L(10);
		System.out.println(l1);
		M m1=new M(20,30);
		System.out.println(m1);

	}

}
