package com.objectclass;

public class A265 implements Cloneable
{
		int i;
		public static void main(String[] args)throws CloneNotSupportedException
		{
			A265 a1=new A265();
			a1.i=10;
			 A265 a2=(A265)a1.clone();
			 a2.i=20;
			 System.out.println(a2.i);
			 System.out.println(a1.i);
			

	    }

}
