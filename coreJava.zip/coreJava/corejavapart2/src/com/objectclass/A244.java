package com.objectclass;
class I
{
	int x;
	I(int x)
	{
		this.x=x;
	}
	public String toString()
	{
		return "x="+x;
		
	}
}
public class A244
{

	public static void main(String[] args) 
	{
		I i1=new I(10);
		String s1="hello===="+i1;
		System.out.println(s1);
		
	}

}
