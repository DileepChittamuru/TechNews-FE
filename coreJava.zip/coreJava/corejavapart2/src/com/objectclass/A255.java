package com.objectclass;
class H1
{
	int i;
	double d;
	H1(int i,double d)
	{
		this.i=i;
		this.d=d;
		
	}
	public String toString()
	{
		return "i="+i+",d="+d;
	}
	public boolean equals(Object obj)
	{
		H1 myobj=(H1)obj;
		boolean flag=(myobj.i==i&&myobj.d==d);
		return flag;
	}
}
public class A255 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		H1 h1=new H1(9, 20.9);
		H1 h2=new H1(9, 20.9);
		System.out.println(h1);
		System.out.println(h2);
		
		System.out.println(h1.equals(h2));
	}

}
