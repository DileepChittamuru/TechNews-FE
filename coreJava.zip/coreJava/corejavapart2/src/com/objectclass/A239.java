package com.objectclass;
class B239
{
	int i;
	B239(int i)
	{
		this.i=i;
	}
	
}
public class A239 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B239 b=new B239(10);
		System.out.println(b);
		String s1=b.toString();
		System.out.println(s1);
		System.out.println(b.toString());
		
		
	}

}
