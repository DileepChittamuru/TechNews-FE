package com.objectclass;
class S
{
	int i;
}
public class A259 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		S s1=new S();
		S s2=new S();
		s1.i=s2.i=10;
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s1.equals(s2));
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
	}

}
