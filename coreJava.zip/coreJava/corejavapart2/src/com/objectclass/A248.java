package com.objectclass;
class A1
{
	int i;
}
public class A248 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a1=new A();
		a1.i=10;
		
		
		 A a2=new A();
		 a2.i=10;
		 
		 
		 A a3=a2;
		 
		 System.out.println(a1==a2);//false
		 System.out.println(a2==a1);//false
		 System.out.println(a2==a3);//t
		 System.out.println(a3==a2);//t
		 
	}

}
