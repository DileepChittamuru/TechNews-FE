package com.objectclass;
class B1
{
	int i;
}
public class A249 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B1 b=new B1();
		b.i=20;
		
		B1 b1=new B1();
		b1.i=20;
		
		B1 b2=b1;
		
	System.out.println(b==b1);//f
	System.out.println(b1==b2);//t
	System.out.println(b2==b1);//t
	System.out.println(b1.i==b.i);//t
	
		
		
	}

}
