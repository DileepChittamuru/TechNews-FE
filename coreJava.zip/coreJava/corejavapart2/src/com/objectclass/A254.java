package com.objectclass;
class G1
{
	int i,j;
	G1(int i,int j)
	{
		this.i=i;
		this.j=j;
	}
	public boolean equals(Object obj)
	{
		G1 myobj=(G1)obj;
		return this.i==myobj.i&&this.j==myobj.j;
	}
}
public class A254 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			G1 g1=new G1(1, 2);
			G1 g2=new G1(1, 2);
			System.out.println(g1.equals(g2));
	}

}
