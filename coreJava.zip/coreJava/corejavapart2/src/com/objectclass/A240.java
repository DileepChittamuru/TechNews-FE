package com.objectclass;
class D
{
	int i;
	D(int i)
	{
		this.i=i;
	}
}
public class A240 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		D d1=new D(10);
		D d2=new D(20);
		D d3=d1;
		D d4=d2;
		System.out.println(d1);
		System.out.println(d2);
		System.out.println(d3);
		System.out.println(d4);
	}

}
