package com.objectclass;
class E
{
	int i,j;
	E(int i,int j)
	{
		this.i=i;
		this.j=j;
	}
	public String toString()
	{
		return "i:"+i+",j:"+j;
		
	}
}
public class A241 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		E e1=new E(20,40);
		System.out.println(e1);
		 E e2=new E(30,50);
		 System.out.println(e2);
	}

}
