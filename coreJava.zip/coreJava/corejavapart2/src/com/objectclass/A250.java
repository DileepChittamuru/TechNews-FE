package com.objectclass;
class C1
{
	int i;
	C1(int i)
	{
		this.i=i;
	}
}
public class A250
{
	public static void main(String[] args)
	{
		C1 c=new C1(10);
		C1 c1=new C1(10);
		System.out.println(c==c1);
		System.out.println(c1.equals(c));
			
	}

}
