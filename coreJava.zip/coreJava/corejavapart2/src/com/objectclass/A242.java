package com.objectclass;
class F 
{
	String s1;
	int i;
	F(String s1,int i)
	{
		this.i=i;
		this.s1=s1;
	}
	public String toString()
	{
		return "i="+i+",s1="+s1;
	}
}
public class A242 
{
	public static void main(String[] args)
	{
		F f1=new F("dileep",21);
		System.out.println(f1);
		F f2=new F("madhuri", 21);
		System.out.println(f2);
			

	}

}
