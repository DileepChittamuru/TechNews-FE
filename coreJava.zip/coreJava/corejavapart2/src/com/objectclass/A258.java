package com.objectclass;
class R
{
	int i,j;
	double weight;
	R(int i,int j,double weight)
	{
		this.i=i;
		this.j=j;
		this.weight=weight;
	}
	
}
public class A258
{

	
	public static void main(String[] args) 
	{
		

	}

}
