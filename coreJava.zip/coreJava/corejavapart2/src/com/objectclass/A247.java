package com.objectclass;
class N
{
	
}
public class A247 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	N n1=null;
	System.out.println(n1);
	String s1=n1+"abc";
	System.out.println(s1);
	}

}
