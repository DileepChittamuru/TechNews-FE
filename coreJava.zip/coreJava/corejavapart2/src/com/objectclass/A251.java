package com.objectclass;
class D1
{
	int i;
	D1(int i)
	{
		this.i=i;
	}
}
public class A251 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		D1 d1=new D1(10);
		D1 d2=d1;
		System.out.println(d1==d2);
		System.out.println(d1.equals(d2));
		
	}

}
