package com.objectclass;
//DEEP COPY
public class A267  implements Cloneable
{
	int i;
	double d;
	String s1;
	Integer obj;
	A267(int i,double d,String s1,Integer obj)
	{
		this.i=i;
		this.d=d;
		this.s1=s1;
		this.obj=obj;
	}
	public String toString()
	{
		return "i="+i+",d:"+d+",s1:"+s1+",obj:"+obj;
	}
	
	public static void main(String[] args)throws CloneNotSupportedException
	{
		A267 a=new A267(20, 2.8, "abc", 45);
		System.out.println(a);
		A267 a1=(A267)a.clone();
		System.out.println(a1);
		a.i=40;
		a.d=3.8;
		a.s1="cdr";
		a.obj=400;
		System.out.println(a);
		System.out.println(a1);

	}

}
