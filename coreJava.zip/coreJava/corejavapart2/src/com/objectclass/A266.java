package com.objectclass;

public class A266 implements Cloneable
{
	int i;
	
	/**
	 * @param args
	 */
	public static void main(String[] args)throws CloneNotSupportedException
	{
		// TODO Auto-generated method stub
				A266 a1=new A266();
				a1.i=20;
				
				A266 a2=(A266)a1.clone();
				System.out.println("a:"+a2.i);
				a2.i=30;
				System.out.println("b:"+a1.i);
				System.out.println("c:"+a2.i);
				a2.i=40;
				System.out.println();
				System.out.println("d:"+a2.i);
	}

}
