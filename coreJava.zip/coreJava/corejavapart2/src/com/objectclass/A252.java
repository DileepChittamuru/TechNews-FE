package com.objectclass;
class E1
{
	int i;
	E1(int i)
	{
		this.i=i;
	}
	public boolean equals(Object obj)
	{
		return this==obj;
	}
}
public class A252 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		E1 e=new E1(10);
		E1 e1=new E1(10);
		E1 e2=e1;
		
		System.out.println(e==e1);
		System.out.println(e1==e2);
		System.out.println(e2==e);
		
		System.out.println(e.equals(e1));
		System.out.println(e1.equals(e2));
		System.out.println(e2.equals(e));
	}

}
