package com.objectclass;
class F1
{
	int i;
	F1(int i)
	{
		this.i=i;
	}
	
	public boolean equals(Object obj)
	{
		F1 myobj=(F1)obj;
		return this.i==myobj.i;
	}
}
public class A253 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		F1 f1=new F1(10);
		F1 f2=new F1(10);
		System.out.println(f1==f2);
		System.out.println(f1.equals(f2));
	}

}
