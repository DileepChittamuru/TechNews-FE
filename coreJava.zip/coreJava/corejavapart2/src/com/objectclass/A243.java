package com.objectclass;
class G
{
	int i;
	G(int i)
	{
		this.i=i;
	}
	public String toString()
	{
		return "i:"+i;
	}
}
class H 
{
	G g1;
	int j;
	H(G g1,int j)
	{
		this.g1=g1;
		this.j=j;
	}
	public String toString()
	{
		return g1+",j="+j;
	}
}
public class A243 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		G g1=new G(10);
		H h1=new H(g1, 90);
		System.out.println(g1);
		System.out.println(h1);
	}

}
