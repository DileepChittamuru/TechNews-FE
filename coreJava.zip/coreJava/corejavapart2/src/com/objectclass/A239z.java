package com.objectclass;
class C239z
{
	int i;
	public C239z(int i) {
		// TODO Auto-generated constructor stub
		this.i=i;
	}
	public String toString()
	{
	return "i="+i;	
	}
}
public class A239z {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C239z c=new C239z(10);
		System.out.println(c);
		C239z c1=new C239z(20);
		System.out.println(c1);
	}

}
