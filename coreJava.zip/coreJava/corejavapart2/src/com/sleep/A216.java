package com.sleep;
class H extends Thread
{
	public void run()
	{
		for(int i=0;i<3000;i++)
		{
			System.out.println(i);
		}
		
	}
}
public class A216 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			H h1=new H();
			h1.setDaemon(true);
			h1.start();
			System.out.println("done");
	}

}
