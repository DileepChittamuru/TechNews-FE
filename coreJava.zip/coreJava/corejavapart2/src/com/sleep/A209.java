package com.sleep;
class B implements Runnable
{

	@Override
	public void run() 
	{
		// TODO Auto-generated method stub
		for(int i=0;i<10;i++)
		{
			System.out.println(i);
			try
			{
				Thread.sleep(1000);
			}
			catch(InterruptedException e1)
			{
				System.out.println(e1);
			}
		}
	}
	
}
public class A209 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B b1=new B();
		Thread t1=new Thread(b1);
		t1.start();
		for(int i=10;i<20;i++)
		{
			System.out.println(i);
			try
			{
				Thread.sleep(1000);
			}
			catch(InterruptedException e1)
			{
				System.out.println(e1);
			}
		}
	}

}
