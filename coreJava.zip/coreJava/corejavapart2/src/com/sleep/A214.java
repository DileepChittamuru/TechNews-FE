package com.sleep;

public class A214 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Thread t1=Thread.currentThread();
			t1.setPriority(11);
			System.out.println(t1.getPriority());
	}

}
