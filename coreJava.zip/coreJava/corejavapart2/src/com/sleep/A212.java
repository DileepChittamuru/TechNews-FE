package com.sleep;
class E1 extends Thread
{
	
}
public class A212 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		E1 e1=new E1();
		e1.setName("firstThread");
		e1.start();
		
		E1 e2=new E1();
		e2.setName("secindThread");
		e2.start();
		
		System.out.println(e1.getId());
		System.out.println(e1.getName());
		System.out.println(e1.getPriority());
		System.out.println(e1.isDaemon());
		
		System.out.println("===========");
		System.out.println(e2.getId());
		System.out.println(e2.getName());
		System.out.println(e2.getPriority());
		System.out.println(e2.isDaemon());
	}

}
