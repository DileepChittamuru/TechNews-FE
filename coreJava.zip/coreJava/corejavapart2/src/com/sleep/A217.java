package com.sleep;
class I extends Thread
{
	public void run()
	{
		for(int i=0;i<1000;i++)
		{
			System.out.println(i);
		}
	}
}
public class A217 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		I i1=new I();
		i1.start();
		try
		{
			i1.join();
		}
		catch(InterruptedException e1)
		{
			System.out.println(e1);
		}
		for(int i=1000;i<2000;i++)
		{
			System.out.println(i);
		}
	}

}
