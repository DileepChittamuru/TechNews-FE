package com.sleep;

public class A215 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		class A extends Thread
		{
			
		}
		A a1=new A();
		System.out.println(a1.getPriority());
		Thread t1=Thread.currentThread();
		t1.setPriority(Thread.MAX_PRIORITY);
		A a2=new A();
		System.out.println(a2.getPriority());
	}

}
