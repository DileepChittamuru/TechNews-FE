package com.sleep;
class Util
{
	static void sleep(long millis)
	{
		try
		{
			Thread.sleep(millis);
		}
		catch(InterruptedException e1)
		{
			System.out.println(e1);
		}
	}
}
class D extends Thread
{
	public void run()
	{
		for(int i=0;i<10;i++)
		{
			System.out.println(i);
			Util.sleep(1000);
		}
	}
}
class E implements Runnable
{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=10;i<20;i++)
		{
			System.out.println(i);
			Util.sleep(1000);
		}
	}
	
}
public class A210 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			D d=new D();
			d.start();
			
			E e1=new E();
			Thread t1=new Thread(e1);
			t1.start();
			
			for(int i=20;i<40;i++)
			{
				System.out.println(i);
				Util.sleep(1000);
			}
	}

}
