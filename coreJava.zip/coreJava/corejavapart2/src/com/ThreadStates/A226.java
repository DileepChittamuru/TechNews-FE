package com.ThreadStates;

public class A226 {

	
	public static void main(String[] args)
	{
		Thread.State states[]=Thread.State.values();
		for(Thread.State states1:states)
		{
			System.out.println(states1);
		}
	}

}
