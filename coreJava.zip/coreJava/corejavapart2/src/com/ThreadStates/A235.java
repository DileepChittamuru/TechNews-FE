package com.ThreadStates;
class Thread1 extends Thread
{
	Thread1(ThreadGroup tg,String name)
	{
		super(tg,name);
	}
	public void run()
	{
		for(int i=0;i<1000;i++)
		{
			System.out.println(i);
		}
	}
	
}
class Thread2 implements Runnable
{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=1000;i<2000;i++)
		{
			System.out.println(i);
		}
	}
	
}
public class A235 
{
	public static void main(String[] args) 
	{
		
		ThreadGroup tg=new ThreadGroup("firstgroup");
		Thread1 t1=new Thread1(tg, "firstname");
		Thread1 t2=new Thread1(tg,"second thread");
		Thread2 t3=new Thread2();
		Thread  t4=new Thread(tg,t3, "third thread");
		Thread t5=new Thread(tg,t3,"fourth group");
		t1.start();
		//t2.start();
		//t4.start();
		t5.start();
		
	}

}
