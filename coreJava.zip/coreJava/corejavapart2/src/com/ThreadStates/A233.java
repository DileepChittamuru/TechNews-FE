package com.ThreadStates;
class Util
{
	static void sleep(long millis)
	{
		try
		{
			Thread.sleep(millis);
		}
		catch(InterruptedException e)
		{
			System.out.println(e);
		}
	}
}
class Test
{
	int i;
}
class AA extends Thread
{
	Test t;
	AA(Test t)
	{
		this.t=t;
	}
	public void run()
	{
		System.out.println("1:"+t.i);
		t.i=10;
		Util.sleep(500);
		System.out.println("2:"+t.i);
		t.i=20;
		Util.sleep(500);
		System.out.println("3:"+t.i);
		t.i=30;
		Util.sleep(500);
		System.out.println("4:"+t.i);
		t.i=40;
		Util.sleep(500);
		System.out.println("5:"+t.i);
		t.i=50;
		Util.sleep(500);
		System.out.println("6:"+t.i);
		t.i=60;
	}
}
class BB extends Thread
{
	Test t;
	BB(Test t)
	{
		this.t=t;
	}
	public void run()
	{
		System.out.println("7:"+t.i);
		t.i=70;
		Util.sleep(500);
		System.out.println("8:"+t.i);
		t.i=80;
		Util.sleep(500);
		System.out.println("9:"+t.i);
		t.i=90;
		Util.sleep(500);
		System.out.println("10:"+t.i);
		t.i=100;
		Util.sleep(500);
		System.out.println("11:"+t.i);
		t.i=110;
		Util.sleep(500);
		System.out.println("12:"+t.i);
		t.i=120;
	}
}
public class A233
{


	public static void main(String[] args)
	{
		Test t1=new Test();
		t1.i=90;
		AA a1=new AA(t1);
		a1.start();
		Util.sleep(250);
		BB b1=new BB(t1);
		b1.start();
		Util.sleep(40000);
		System.out.println("9:"+t1.i);

	}

}
