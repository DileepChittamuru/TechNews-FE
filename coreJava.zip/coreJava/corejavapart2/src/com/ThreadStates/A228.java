package com.ThreadStates;
class B extends Thread
{
	public void run()
	{
		System.out.println("begin");
		try
		{
			Thread.sleep(1000);
		}
		catch(InterruptedException e1)
		{
			System.out.println(e1);
		}
		
		System.out.println("end");
	}
}
public class A228 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B b1=new B();
		System.out.println(b1.getState());
		b1.start();
		System.out.println(b1.getState());
		try
		{
			Thread.sleep(1000);
		}
		catch(InterruptedException e2)
		{
			System.out.println(e2);
		}
		System.out.println(b1.getState());
		
	}

}

