package com.ThreadStates;
class A extends Thread
{
	public void run()
	{
		Thread t1=Thread.currentThread();

		try
		{
			Thread.sleep(5000);
		}
		catch(InterruptedException e1)
		{
			System.out.println(e1);
		}
		System.out.println("d" +
				t1.getState());
	}
	
	
}
public class A227 {

	
	public static void main(String[] args) 
	{
		
	 A a1=new A();
	System.out.println("a:"+a1.getState());
	a1.start();
	System.out.println("b:"+a1.getState());
	/*System.out.println("c:"+a1.getState());
	System.out.println("d:"+a1.getState());
	System.out.println("e:"+a1.getState());*/
	try
	{
		Thread.sleep(100);
	}
	catch(InterruptedException e1)
	{
		System.out.println(e1);
	}
	System.out.println("f:"+a1.getState());
	System.out.println("g:"+a1.getState());
	System.out.println("h:"+a1.getState());
	}

}
