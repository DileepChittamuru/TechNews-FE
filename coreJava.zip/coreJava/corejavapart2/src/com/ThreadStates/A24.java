package com.ThreadStates;
class Util1
{
	static void sleep(long millis)
	{
		try
		{
			Thread.sleep(millis);
		}
		catch(InterruptedException e)
		{
			System.out.println(e);
		}
	}
}
class A1 extends Thread
{
	ThreadLocal t;
	A1(ThreadLocal t)
	{
		this.t=t;
	}
	public void run()
	{
		System.out.println("1:"+t.get());
		t.set(10);
		Util1.sleep(500);
		System.out.println("2:"+t.get());
		t.set(20);
		Util1.sleep(500);
		System.out.println("3:"+t.get());
		t.set(30);
		Util1.sleep(500);
		System.out.println("4:"+t.get());
		t.set(40);
	}
}
class B1 extends Thread
{
	ThreadLocal t;
	B1(ThreadLocal t)
	{
		this.t=t;
	}
	public void run()
	{
		System.out.println("5:"+t.get());
		t.set(50);
		Util1.sleep(500);
		System.out.println("6:"+t.get());
		t.set(60);
		Util1.sleep(500);
		System.out.println("7:"+t.get());
		t.set(70);
		Util1.sleep(500);
		System.out.println("8:"+t.get());
		t.set(90);
	}
}
public class A24 {

	
	public static void main(String[] args) 
	{
		ThreadLocal t1=new ThreadLocal<>();
		t1.set(90);
		A1 a=new A1(t1);
		a.start();
		Util.sleep(250);
		B1 b1=new B1(t1);
		b1.start();
		Util.sleep(40000);
		System.out.println("9:"+t1.get());
	}

}
