package com.Strings2;

public class A354 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.printf("%d",98765432);
		System.out.println("");
		System.out.printf("%.2f",987654.321);
	}

}
