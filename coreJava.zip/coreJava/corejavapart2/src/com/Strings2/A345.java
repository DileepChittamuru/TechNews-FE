package com.Strings2;

public class A345 {

	
	public static void main(String[] args)
	{
	System.out.printf("======%2$d========%1$d=======\n",4,5);	
	System.out.printf("====%3$d======%2$d=====%1$d======",2,3,4);

	}

}
