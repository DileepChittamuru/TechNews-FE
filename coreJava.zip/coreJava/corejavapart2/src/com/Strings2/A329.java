package com.Strings2;

public class A329 {

	
	public static void main(String[] args) 
	{
	StringBuffer sb1=new StringBuffer();
	sb1.append("abc");
	sb1.append("cdr");
	System.out.println("===========");
	StringBuffer sb2=new  StringBuffer();
	sb2.append("abc");
	sb2.append("cdr");
	System.out.println(sb1.equals(sb2));
	System.out.println(sb1.hashCode());
	System.out.println("==================");
	System.out.println(sb2.hashCode());

	}

}
