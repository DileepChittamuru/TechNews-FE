package com.Strings2;

public class A339 {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		System.out.printf("%d + %d=%d",10,3,13);
		System.out.println(" ");
		int i=10,j=13,k=13;
		System.out.printf("%d + %d=%d",i,j,k);

	}

}
