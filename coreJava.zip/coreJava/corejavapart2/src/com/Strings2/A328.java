package com.Strings2;

public class A328 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="abc";
		StringBuffer sb=new StringBuffer(s1);
		sb.append("def");
		sb.append("ghi");
		System.out.println(sb);
	}

}
