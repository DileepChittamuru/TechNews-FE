package com.Strings2;

public class A326 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb=new StringBuffer("abc");
		sb.append("xyz");
		sb.append("\n");
		sb.append("hello\t");
		sb.append("xyz");
		System.out.println(sb);
	}

}
