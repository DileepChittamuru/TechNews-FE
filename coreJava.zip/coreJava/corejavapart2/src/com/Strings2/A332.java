package com.Strings2;

public class A332 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1=" abc xyz ";
		s1.trim();
		System.out.println(s1.length());
		s1=s1.trim();
		System.out.println(s1.length());
		System.out.println("===================");
		StringBuffer sb=new StringBuffer();
		sb.append(" abc xyz ");
		System.out.println("before trim to size");
		System.out.println(sb.capacity());//by default 16
		sb.trimToSize();
		System.out.println("after trim to size");//size is 9 with spaces
		System.out.println(sb.capacity());
		
	}

}
