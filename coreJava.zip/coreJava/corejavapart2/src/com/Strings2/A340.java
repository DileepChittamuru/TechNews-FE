package com.Strings2;

import java.util.Scanner;

public class A340 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter sth");
		String s=sc.next();
		System.out.printf("welcome to  novotel MR:%s sir",s);
		
	}

}
