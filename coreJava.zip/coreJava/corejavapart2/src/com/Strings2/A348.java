package com.Strings2;

public class A348 {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		System.out.printf("======>%10d<=========",1000);
		System.out.println("");
		System.out.printf("=======>%d<========",100);
	}

}
