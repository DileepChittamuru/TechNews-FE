package com.Strings2;

public class A353 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.printf("[%0(10d]",-23456);
	}

}
