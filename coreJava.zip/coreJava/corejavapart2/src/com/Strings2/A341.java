package com.Strings2;

import java.util.Scanner;

public class A341 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("entr sth");
		int i=Integer.parseInt(sc.next());
		System.out.printf("the age of student is %d",i);
		
	}

}
