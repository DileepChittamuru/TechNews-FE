package com.Strings2;

public class A333 {

	
	public static void main(String[] args)
	{
		StringBuffer sb=new StringBuffer();
		sb.append("abababacabcab");
		sb.append("abcabcabc");
		System.out.println(sb.capacity());
		sb.trimToSize();
		System.out.println(sb.capacity());
		System.out.println(sb.length());

	}

}
