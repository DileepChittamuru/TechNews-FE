package com.Strings2;

public class A338 {

	
	public static void main(String[] args) 
	{
		System.out.printf("hello %s","india");
		System.out.println("");
		String s1="indian";
		//System.out.printf("hello %s",s1);
		String s2="hello";
		System.out.printf("welcome %s %s",s1,s2);
		

	}

}
