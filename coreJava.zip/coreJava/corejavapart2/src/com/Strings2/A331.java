package com.Strings2;

public class A331 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb=new StringBuffer("abcxyzhello");
		System.out.println(sb);
		System.out.println("===============");
		sb.delete(3 , 6);//3 inclusive 6 exclusive
		System.out.println(sb);
		System.out.println("==================");
		sb.deleteCharAt(1);
		System.out.println(sb);
		System.out.println("===========");
		System.out.println(sb);
		
	}

}
