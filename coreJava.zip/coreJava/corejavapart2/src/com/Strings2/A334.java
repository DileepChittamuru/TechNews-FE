package com.Strings2;

public class A334 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb=new StringBuffer();
		sb.append("abc");
		sb.append("xyz");
		sb.append("hello");
		System.out.println(sb);
		System.out.println(sb.toString());
		System.out.println("=========");
		System.out.println(sb.substring(3));
		System.out.println("===========");
		System.out.println(sb);
		System.out.println(sb.substring(3, 8));
		sb.substring(3,8);
		System.out.println(sb);
		System.out.println("==========");
		System.out.println(sb.subSequence(1, 3));
	}

}
