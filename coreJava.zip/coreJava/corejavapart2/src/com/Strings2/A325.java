package com.Strings2;

public class A325 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb=new StringBuffer();
		sb.append("abc");
		sb.append("cdr");
		sb.append("cgr");
		sb.append("cpr");
		sb.append("cdr");
		System.out.println(sb);
		sb.append("csr");
		System.out.println(sb);
		System.out.println("==============");
		
		
	}

}
