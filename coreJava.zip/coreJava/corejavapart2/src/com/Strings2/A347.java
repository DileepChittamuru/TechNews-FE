package com.Strings2;

import java.util.Scanner;

public class A347 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.print("enter i value");
		int i=Integer.parseInt(sc.next());
		System.out.print("enter j value");
		int j=Integer.parseInt(sc.next());
		System.out.print("before swaping values are\n");
		System.out.printf("i=%1$d ,j=%2$d\n",i,j);
		System.out.print("after swapping\n");
		System.out.printf("i=%2$d,j=%1$d",i,j);
	}

}
