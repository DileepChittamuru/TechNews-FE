package com.Strings2;

public class A342 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.printf("pi value is=%f",Math.PI);
	}

}
