package com.Strings2;

public class A351 {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		System.out.printf("%+d",20);

	}

}
