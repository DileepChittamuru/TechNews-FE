package com.Strings2;

public class A336 
{
	public static void main(String[] args)
	{
		StringBuilder sb=new StringBuilder();
		sb.append("abc");
		sb.append("hello");
		//sb.append(sb);
		System.out.println("===========");
		System.out.println(sb.delete(0,3));
		System.out.println(sb);
		System.out.println("=========");
		System.out.println(sb.deleteCharAt(4));
		System.out.println(sb);
		
	}

}
