package com.Strings2;

public class A335 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder sb=new StringBuilder();
		sb.append("abc");
		sb.append("xyz");
		System.out.println(sb.toString());
		System.out.println("===========");
		StringBuilder sb1=new StringBuilder("abcxyz");
		System.out.println(sb1.toString());
		System.out.println("===========");
		System.out.println(sb1==sb);
		System.out.println("===========");
		System.out.println(sb.equals(sb1));
		System.out.println("===============");
		System.out.println(sb.hashCode());
		System.out.println(sb1.hashCode());
		
	}

}
