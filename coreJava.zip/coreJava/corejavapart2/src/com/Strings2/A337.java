package com.Strings2;
public class A337 
{
	public static void main(String[] args) 
	{
		StringBuffer sb = new StringBuffer();
		sb.append("abc");
		
		System.out.println(sb);
		StringBuilder sb1 = new StringBuilder();
		
		sb1.append("abc");
	     
		System.out.println(sb1);
		System.out.println("done");
		
	}

}
