package com.Strings2;

public class A344 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.printf("====%d=====%d",4,5);
	}

}
