package com.Strings2;

public class A343 
{

 public static void main(String[] args)
	{
	 System.out.printf("thread maximum priority is :%d\n",Thread.MAX_PRIORITY);
	 System.out.printf("thread minimum priority is :%d\n",Thread.MIN_PRIORITY);
	 System.out.printf("thread minimum priority is: %d\n",Thread.NORM_PRIORITY);
	 System.out.printf("current Thread is :%s\n",Thread.currentThread());

	}

}
