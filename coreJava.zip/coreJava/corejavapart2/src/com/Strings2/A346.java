package com.Strings2;

public class A346 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.printf("=======%2$d===========%3$s=========\n",10,2,"dileep");
		System.out.printf("===========%3$f=======%2$d===========",21,23,23.99);
		
	}

}
