package com.Strings2;

public class A352 {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.printf("%+d",23456);
	}

}
