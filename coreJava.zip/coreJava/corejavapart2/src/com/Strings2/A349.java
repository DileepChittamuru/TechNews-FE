package com.Strings2;

public class A349 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.printf("(%2$10s)----(%1$20d)",100,"cdr");
		
	}

}
