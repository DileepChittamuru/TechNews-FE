package com.synchronization;
class A 
{
	synchronized  void test1()
	{
		for(int i=0;i<2000;i++)
		{
			System.out.println(i);
		}
	}
	 void test2()
	{
		for(int i=2000;i<4000;i++)
		{
			System.out.println(i);
		}
	}
}
class B extends Thread
{
	A a1;
	B(A a1)
	{
		this.a1=a1;
	}
	public void run()
	{
		a1.test1();
	}
}
class C extends Thread
{
	A a1;
	C(A a1)
	{
		this.a1=a1;
	}
	public void run()
	{
		a1.test2();
	}
}
public class A219 {

	
	public static void main(String[] args)
	{
		A a1=new A();
		B b1=new B(a1);
		C c1=new C(a1);
		b1.start();
		c1.start();
		
			
	}

}
