package com.interthreadcommunication;
class AAA
{
	synchronized void test1()
	{
		try
		{
			wait();
		}
		catch(InterruptedException e1)
		{
			System.out.println(e1);
		}
	}
	synchronized void test2()
	{
		notifyAll();
		
	}
}
class Thread3 extends Thread
{
	AAA a1;
	Thread3(AAA a1)
	{
		this.a1=a1;
	}
	public void run()
	{
		System.out.println(1);
		a1.test1();
		System.out.println(2);
	}
}
class Thread4 extends Thread
{
	AAA a1;
	Thread4(AAA a1)
	{
		this.a1=a1;
		
	}
	public void run()
	{
		System.out.println(3);
		a1.test1();
		System.out.println(4);
	}
}
public class A223 {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		AAA a1=new AAA();
		Thread3 t3=new Thread3(a1);
		Thread4 t4=new Thread4(a1);
		t3.start();
		t4.start();
		try
		{
			Thread.sleep(20000);
			
		}
		catch(InterruptedException e1)
		{
			System.out.println(e1);
		}
		a1.test2();
	}

}
