/** 
*  Function's Prototype : 
*  Person prototype is an object instance
*  That will be the prototype for all the object's(dileep, rajini) created from function as a contructor
*
* Example 
* Person is an Object 
* This Person Object will be prototope for all the object created from Person constrcutor function
**/

var Person = function(exp, age) {
    this.exp = exp;
    this.age = age;
};

/*
* Object prototype:
* Object Protype is an Object instance from which the object is inherited.
* 
* example dileep has object prototype(__proto__) it has Person Object because dileep is inherited from person Object.
*/
var dileep = new Person('5', 25);
var rajini = new Person('8', 32);



dileep.country = 'Amsterdam';
Person.prototype.country = 'India'

Person.prototype.district = 'Nellore';



console.log('dileep', dileep); // {exp: "5", age: 25, country: "Amsterdam"}
console.log('country', dileep.country); // Amsterdam
console.log('proto country', dileep.__proto__.country); // india
console.log(Object.keys(dileep)); // {exp: "5", age: 25, country: "Amsterdam"}


