function myConcat(separator) {
   var result = ''; // initialize list
   var i;
   // iterate through arguments
   for (i = 0; i < arguments.length; i++) {
    console.log(arguments[i]);
   }
}

// returns "red, orange, blue, "
myConcat('red', 'orange', 'blue');

// returns "elephant; giraffe; lion; cheetah; "
//myConcat('; ', 'elephant', 'giraffe', 'lion', 'cheetah');

// returns "sage. basil. oregano. pepper. parsley. "
//('. ', 'sage', 'basil', 'oregano', 'pepper', 'parsley');