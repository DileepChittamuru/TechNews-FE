'use strict';

function Animal(voice) {
  this.voice = voice || 'grount';
};

Animal.prototype.speak = function() {
  console.log(this.voice)
};


var cat = function(name, color) {
    Animal.call(this, 'meow')
    this.name = name;
    this.color = color;
   // console.log('this', this.name);
};

var fluffy =  new cat('dileep', 'red');


