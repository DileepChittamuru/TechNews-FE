
// ============== Undefined ===========================

  var x;
  console.log("y is", x) // undefined

  console.log("k is", y); // undefined
  var y = 5;

// =============== Reference Error =====================

 	// console.log("k is", k); // Reference error

  // console.log('A is', a); // refernce error
  let a = 21;
	 
// ============== Blocked scope ===========================


	if (z === undefined)	{
		var z = 5
	}
	 console.log("z is", z);

  if (false) {
    var n = 100;
  }
   console.log("n is ", n);

// ==================== variable hoisting ===================
 
  (function() {

    if (false) {
      var myvar = 'hdd';
      var chin = '123'
    }

    console.log("jjjj", myvar); // undefined
    // var myvar;
     myvar = 'local value';
  })();

  //=================== function hoisting =========================

  boo();

  function boo() {
    console.log("boo function declaration");
  }

 // zoo();

  var zoo = function() {
    console.log("function expression")
  }

  // ===== constants ======================================

  const pi = 3.14;
  // pi = 5.6; //we can't declare

  const tb = {key: 'value'};
  tb.key = 'cdr';
  console.log("tb", tb) //  we can't protect the proeprties of constant

  const ap = ['ab', 'cd'];
  ap.push('ef');
  console.log("ap", ap);

  