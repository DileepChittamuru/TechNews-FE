// creation of object
var strltrl = "2 + 2";
var strObject = new String('2+2');
console.log('strltrl' + strltrl);
console.log('strObject'+ strObject);

// String are immutable

var mystring = 'Hello, World!';
console.log("mystring"+ mystring[0]);
var x = mystring.length;
mystring[0] = 'L'; // This has no effect, because strings are immutable
mystring[0];
console.log("mystring[0]"+ mystring[0]);

// methods
// =================charAt===========

var str = "HelloStringWorld";

console.log(str.charAt(2)) // returns l

//============concat====================

var str1 = "welcome dileep";
var str3 = str.concat(str1);

console.log(str.concat(str1)) // returns HelloStringWorldwelcome dileep

// ==============indeOf=================

var indx = "dileep reddy";
console.log(indx.indexOf("dhsdjh"));