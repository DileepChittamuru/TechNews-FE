function map(f, a) {
  var result = []; // Create a new Array
  var i; // Declare variable
  for (i = 0; i != a.length; i++)
    result[i] = f(a[i]);
      return result;
}
var f = function(x) {
   return x * x * x; 
}
var numbers = [0, 1, 2, 5, 10];
var cube = map(f, numbers);
console.log(cube);


function foo(i) {
  if (i < 0)
    return;
  console.log('begin: ' + i); // 3 2 1 0 
  foo(i - 1);
  console.log('end: ' + i); //
}
foo(3)

