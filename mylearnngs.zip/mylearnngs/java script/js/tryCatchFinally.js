function getMonthName(mo) {
  console.log("calling", mo)
  mo = mo - 1; // Adjust month number for array index (1 = Jan, 12 = Dec)
  var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul',
                'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  if (months[mo]) {
    return months[mo];
  } else {
    throw 'InvalidMonthNo'; //throw keyword is used here
  }
}

function logMyErrors(e) {
  console.log("e", e);
}

try { // statements to try
  var myMonth = 11;
  monthName = getMonthName(myMonth); // function could throw exception
  console.log("monthName", monthName)
}
catch (e) {
  monthName = 'unknown';
  logMyErrors(e); // pass exception object to error handler -> your own function
}


try {
  throw 'myException'; // generates an exception
}
catch (e) {
  // statements to handle any exceptions
  logMyErrors(e); // pass exception object to error handler
}

// continue

var i = 0;
var n = 0;
while (i < 5) {
  i++;
  console.log("i", i)
  if (i == 3) {
    console.log(i, "continue")
    continue;
  }
  n =  n+i; 

}


// for- in

// for - off



