function loop(x) {
  if (x >= 10) 
    return;
    console.log('begin:'+x);
   loop(x + 1);
    console.log('end:'+x);
}

loop(0);

/*
* begin 0 to 9
* end 9 to 0
*
*/