'use strict'
// Constructor function
function Person(name, last, age, gender, interests) {
    this.name = name;
    this.last = last;
    this.age = age;
    this.gender =gender;
    this.interests = interests;
}

var person1 = new Person('dileep', 'reddy', 21, 'male', 'sex');

console.log('Person', Person.prototype);
console.log('Object', Object.prototype);
console.log('Person', person1.valueOf());
console.log('Person1==>',person1.__proto__ === Person.prototype);

Person('cdr', 'reddy', 21, 'male', 'fucking');
