
// =============Undefined==========================
    var y;
    console.log("y is",y) // undefined
	
// =============Reference error===================

 console.log("k is",k); // Reference error
 var k = 10
 
/*
* ==============Blocked scope========================
*/

if(z === undefined){
    var z = 5
}

console.log("z is", z);

/*
* =============variable hoisting=========================
*/

var myvar = 'my value';
 
(function() {
  if(false){
      var myvar = 'hdd';
      var chin = '123'
  }
  //var myvar;
  console.log(myvar); // undefined
  myvar = 'local value';
})();