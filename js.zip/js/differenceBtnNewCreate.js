// create method
// creating an object from object literal
// create method takes input an object
var dog = {
    eat: function() {
        console.log(this.eatFood)
    }
};
var maddie = Object.create(dog);
console.log("maddie", maddie);
console.log(dog.isPrototypeOf(maddie)); //true
maddie.eatFood = 'NomNomNom'; 
maddie.eat(); //NomNomNom

// ==============================================
//new operator is used to create an instance for constructor function
// new operator
var cat = function () {
    this.sounds = function() {
        console.log('calling ',this.moeow);
    }
}

var pussy = new cat();
pussy.moeow = 'hello'
pussy.sounds();

cat.prototype.age = 25;
var flufy = Object.create(cat.prototype);
console.log(flufy.age)

// curly braces
