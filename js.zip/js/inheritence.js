function Person(first, last, age, gender, interests) {
  this.name = {
    first,
    last
  };
  this.age = age;
  this.gender = gender;
  this.interests = interests;
};

// prototype is an object that has a constrcutor function
Person.prototype.greeting = function() {
  console.log('Hi! I\'m ' + this.name.first + '.');
};

Person.prototype.caste = 'Reddy';
var person1 = new Person('a', 'b', 2, 'm', 'badminton');

console.log("person1", person1.__proto__ === Person.prototype);
console.log("Person ==>",Person.prototype);
console.log("Person1 ==>",person1.__proto__);


function Teacher(first, last, age, gender, interests, subject) {
  Person.call(this, first, last, age, gender, interests);
  this.subject = subject;
}

var teacher1 = new Teacher('a', 'b', 2, 'm', 'badminton', 'eng');

//teacher1.age;